#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "pizzaiolo.h"
#include "../model/db.h"
#include "../view/pizzaiolo.h"
#include "../utils/io.h"

static bool visualizza_pizze_da_preparare(void)
{
    struct pizze_da_preparare *pizzeDaPreparare = do_visualizza_pizze_da_preparare();
    if(pizzeDaPreparare != NULL) {
        print_pizze_da_preparare(pizzeDaPreparare);
        free_pizze_da_preparare(pizzeDaPreparare);
    }
    return false;
}

static bool segna_pizza_pronta(void)
{
    bool done;
    struct pizza_stato pizzaPronta;
    memset(&pizzaPronta, 0, sizeof(pizzaPronta));
    get_pizza_pronta_info(&pizzaPronta);
    done = do_segna_pizza_pronta(&pizzaPronta);

    bool plus_actions;
    while (done) {
        plus_actions = yes_or_no("\nDesideri segnare come pronte altre pizze di questa comanda?", 's', 'n', false, true);
        if (plus_actions) {
            get_plus_pizza_pronta_info(&pizzaPronta);
            done = do_segna_pizza_pronta(&pizzaPronta);
        }else
            return false;
    }
    return false;
}

static bool quit(void) {
    return true;
}

static struct {
    enum actions action;
    bool (*control)(void);
} controls[END_OF_ACTIONS] = {
        {.action = VISUALIZZA_PIZZE_DA_PREPARARE, .control = visualizza_pizze_da_preparare},
        {.action = SEGNA_PIZZA_PRONTA, .control = segna_pizza_pronta},
        {.action = QUIT, .control = quit},
};


void pizzaiolo_controller(void)
{
    db_switch_to_pizzaiolo();

    while (true) {
        int action = get_pizzaiolo_action();
        if(action >= END_OF_ACTIONS) {
            fprintf(stderr, "Errore: azione non riconosciuta\n");
            continue;
        }
        if (controls[action].control())
            break;

        press_anykey();
    }
}