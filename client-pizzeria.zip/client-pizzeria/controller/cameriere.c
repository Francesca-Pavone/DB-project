#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "cameriere.h"
#include "../view/cameriere.h"
#include "../utils/io.h"

static bool visualizza_tavoli_occupati(char *username)
{
    struct lista_tavoli *tavoliOccupati = do_visualizza_tavoli_occupati(username);
    if(tavoliOccupati != NULL) {
        print_tavoli_occupati(tavoliOccupati);
        free(tavoliOccupati);
    }
    return false;
}

static bool visualizza_tavoli_comande_servite(char *username)
{
    struct lista_tavoli *tavoliComandeServite = do_visualizza_tavoli_comande_servite(username);
    if(tavoliComandeServite != NULL) {
        print_tavoli_comandeServite(tavoliComandeServite);
        free(tavoliComandeServite);
    }

    return false;
}


static bool visualizza_cosa_e_dove_servire(char *username)
{
    struct da_servire *daServire = do_visualizza_cosa_e_dove_servire(username);
    if(daServire != NULL) {
        print_cose_da_servire(daServire);
        free_da_servire(daServire);
    }
    return false;
}


static bool plus_ordina_bevanda(struct bevanda_effettiva bevandaEffettiva, char *username)
{
    while (true) {
        bool go = yes_or_no("\n\nDesideri aggiungere altre bevande a questa comanda?", 's', 'n', false, true);
        if (go) {
            get_plus_bevanda_effettiva_info(&bevandaEffettiva);
            do_ordina_bevanda(&bevandaEffettiva, username);
        } else
            return false;
    }
}


static bool ordina_bevanda(char *username)
{
    struct bevanda_effettiva bevandaEffettiva;
    memset(&bevandaEffettiva, 0, sizeof(bevandaEffettiva));
    get_bevanda_effettiva_info(&bevandaEffettiva);
    bool done = do_ordina_bevanda(&bevandaEffettiva, username);
    if(done)
        plus_ordina_bevanda(bevandaEffettiva, username);
    return false;
}


static bool completa_ordinazione_pizza(struct pizza_effettiva *pizzaEffettiva, char *username)
{
    int idPizza = do_ordina_pizza(pizzaEffettiva, username);
    bool done, go, aggiunte;

    if(idPizza > 0) {
        printf("\nL'id della pizza appena ordinata e': %d\n", idPizza);
        struct pizza_stato pizzaOrdinata;
        memset(&pizzaOrdinata, 0, sizeof(pizzaOrdinata));
        pizzaOrdinata.idPizza = idPizza;
        pizzaOrdinata.comanda = pizzaEffettiva->comanda;

        richiesta_aggiunte:
        aggiunte = yes_or_no(
                "\n\n~~~~~~~~~~~~~~~~  Desideri effettuare aggiunte su questa pizza?  ~~~~~~~~~~~~~~~~\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  ",
                's', 'n', false, true);
        if (aggiunte) {
            struct aggiunta_pizza aggiunta;
            memset(&aggiunta, 0, sizeof(aggiunta));
            while (go) {
                aggiunta.comanda = pizzaEffettiva->comanda;
                aggiunta.idPizza = idPizza;
                get_ingrediente_aggiunta_info(aggiunta.ingrediente);
                do_inserisci_aggiunta_pizza(&aggiunta);

                bool plus_aggiunte = yes_or_no("\nCi sono altre aggiunte da effettuare?", 's', 'n', false, true);
                if (!plus_aggiunte) {
                    done = yes_or_no("\nConfermi che l'ordinazione di questa pizza e' stata completata?", 's', 'n',
                                     true, true);
                    if (done) {
                        go = false;
                        do_segna_pizza_ordinata(&pizzaOrdinata);
                    }
                }
            }
        } else {
            done = yes_or_no("\nConfermi che l'ordinazione di questa pizza e' stata completata?", 's', 'n',
                             true, true);
            if (done)
                do_segna_pizza_ordinata(&pizzaOrdinata);
            else {
                go = true;
                goto richiesta_aggiunte;
            }
        }
        return true;

    } else
        return false;
}

static bool plus_ordina_pizza(struct pizza_effettiva pizzaEffettiva, char *username)
{
    while (true) {
        bool go = yes_or_no("\n\nDesideri aggiungere altre pizze a questa comanda?", 's', 'n', false, true);
        if (go) {
            get_plus_pizza_effettiva_info(&pizzaEffettiva);
            completa_ordinazione_pizza(&pizzaEffettiva, username);
        }else
            return false;
    }
}

static bool ordina_pizza(char *username)
{
    struct pizza_effettiva pizzaEffettiva;
    memset(&pizzaEffettiva, 0, sizeof(pizzaEffettiva));
    get_pizza_effettiva_info(&pizzaEffettiva);
    bool done = completa_ordinazione_pizza(&pizzaEffettiva, username);

    if(done)
        plus_ordina_pizza(pizzaEffettiva, username);

    return false;
}


static bool registra_comanda(char *username)
{
    int numeroComanda;
    struct tavolo tavolo;
    memset(&tavolo, 0, sizeof (tavolo));
    get_registrazione_comanda_info(&tavolo);
    numeroComanda = do_registra_comanda(&tavolo, username);

    if(numeroComanda > 0) {
        printf("\nE' stata effettuata la registrazione della comanda con il numero: %d\n\n", numeroComanda);
        press_anykey();
        while (true) {
            int action = get_ordinazione_info();

            if (action == 0)
            {
                struct pizza_effettiva pizzaEffettiva;
                memset(&pizzaEffettiva, 0, sizeof(pizzaEffettiva));
                pizzaEffettiva.comanda = numeroComanda;
                get_plus_pizza_effettiva_info(&pizzaEffettiva);
                completa_ordinazione_pizza(&pizzaEffettiva, username);
                plus_ordina_pizza(pizzaEffettiva, username);
            }
            else if (action == 1)
            {
                struct bevanda_effettiva bevandaEffettiva;
                memset(&bevandaEffettiva, 0, sizeof(bevandaEffettiva));
                bevandaEffettiva.comanda = numeroComanda;
                get_plus_bevanda_effettiva_info(&bevandaEffettiva);
                bool done = do_ordina_bevanda(&bevandaEffettiva, username);
                if (done)
                    plus_ordina_bevanda(bevandaEffettiva, username);
            } else
                return false;
        }
    }
    return false;
}


static bool segna_bevanda_servita(char *username)
{
    bool done;
    struct bevanda_stato bevandaServita;
    memset(&bevandaServita, 0, sizeof(bevandaServita));
    get_bevanda_servita_info(&bevandaServita);
    done = do_segna_bevanda_servita(&bevandaServita, username);

    bool plus_actions;
    while (done) {
        plus_actions = yes_or_no("\nDesideri segnare come servite altre bevande di questa comanda?", 's', 'n', false, true);
        if (plus_actions) {
            get_plus_bevanda_servita_info(&bevandaServita);
            done = do_segna_bevanda_servita(&bevandaServita, username);
        }else
            return false;
    }
    return false;
}

static bool segna_pizza_servita(char *username)
{
    bool done;
    struct pizza_stato pizzaServita;
    memset(&pizzaServita, 0, sizeof(pizzaServita));
    get_pizza_servita_info(&pizzaServita);
    done = do_segna_pizza_servita(&pizzaServita, username);

    bool plus_actions;
    while (done) {
        plus_actions = yes_or_no("\nDesideri segnare come servite altre pizze di questa comanda?", 's', 'n', false, true);
        if (plus_actions) {
            get_plus_pizza_servita_info(&pizzaServita);
            done = do_segna_pizza_servita(&pizzaServita, username);
        }else
            return false;
    }
    return false;
}

static bool quit(char *username) {
    return true;
}

static struct {
    enum actions action;
    bool (*control)(char *username);
} controls[END_OF_ACTIONS] = {
        {.action = VISUALIZZA_TAVOLI_OCCUPATI, .control = visualizza_tavoli_occupati},
        {.action = VISUALIZZA_TAVOLI_COMANDE_SERVITE, .control = visualizza_tavoli_comande_servite},
        {.action = REGISTRA_COMANDA, .control = registra_comanda},
        {.action = VISUALIZZA_COSA_E_DOVE_SERVIRE, .control = visualizza_cosa_e_dove_servire},
        {.action = ORDINA_PIZZA, .control = ordina_pizza},
        {.action = ORDINA_BEVANDA, .control = ordina_bevanda},
        {.action = SEGNA_PIZZA_SERVITA, .control = segna_pizza_servita},
        {.action = SEGNA_BEVANDA_SERVITA, .control = segna_bevanda_servita},
        {.action = QUIT, .control = quit}
};


void cameriere_controller(struct credentials *credentials)
{
    db_switch_to_cameriere();
    while (true) {
        int action = get_cameriere_action();
        if(action >= END_OF_ACTIONS) {
            fprintf(stderr, "Errore: azione non riconosciuta\n");
            continue;
        }
        if (controls[action].control(credentials->username))
            break;
        press_anykey();
    }
}