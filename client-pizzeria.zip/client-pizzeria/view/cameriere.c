#include <stdio.h>

#include "cameriere.h"
#include "../utils/io.h"
#include "../utils/validation.h"

#define NUM_LEN 5

int get_cameriere_action(void)
{
    char *options[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9"};

    clear_screen();
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    puts("|                                                               |");
    puts("|                    SCHERMATA DEL CAMERIERE                    |");
    puts("|                                                               |");
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    puts("~~~~~~~~~~~~~~   Che azione desideri effettuare?   ~~~~~~~~~~~~~~\n");
    puts("1) Visualizzare quali dei miei tavoli sono occupati");
    puts("2) Visualizzare in quali dei miei tavoli le comande sono state completamente servite");
    puts("3) Registrare una nuova comanda");
    puts("4) Visualizzare cosa devo servire ed in che tavolo");
    puts("5) Aggiungere una pizza ad una comanda");
    puts("6) Aggiungere una bevanda ad una comanda");
    puts("7) Segnare che una pizza e' stata servita");
    puts("8) Segnare che una bevanda e' stata servita");
    puts("9) Quit");

    return multi_choice("\nScegli un'opzione", options, 9);
}

int get_ordinazione_info(void) {
    char *options[] = {"1", "2", "3"};

    clear_screen();
    puts("~~~~~~~~~~~~~~~~~~~~~~~~   Che azione desideri effettuare?   ~~~~~~~~~~~~~~~~~~~~~~~~\n");
    puts("1) Prendere l'ordinazione di una pizza");
    puts("2) Prendere l'ordinazione di una bevanda");
    puts("3) Tornare alla schermata iniziale");

    return multi_choice("\nScegli un'opzione", options, 3);
}


void get_registrazione_comanda_info(struct tavolo *tavolo)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("~~~~~~~~  Fornisci i dati richiesta per la registrazione di una comanda  ~~~~~~~~\n");
    get_input("Inserisci il numero del tavolo: ", NUM_LEN, str, false);
    tavolo->numeroTavolo = strtoul(str, &ptr, 10);

}

void get_bevanda_effettiva_info(struct bevanda_effettiva *bevandaEffettiva)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("~~~~~~~~  Fornisci i dati richiesta per l'ordinazione di una bevanda  ~~~~~~~~\n");
    get_input("Inserisci il numero della comanda: ", NUM_LEN, str, false);
    get_input("Inserisci il nome della bevanda: ", NOME_PRODOTTO_LEN, bevandaEffettiva->nomeBevanda, false);
    bevandaEffettiva->comanda = strtoul(str, &ptr, 10);
}

void get_plus_bevanda_effettiva_info(struct bevanda_effettiva *bevandaEffettiva)
{
    clear_screen();
    printf("~~~~~~~~  Fornisci i dati della bevanda da aggiungere alla comanda %u  ~~~~~~~~\n\n", bevandaEffettiva->comanda);
    get_input("Inserisci il nome della bevanda: ", NOME_PRODOTTO_LEN, bevandaEffettiva->nomeBevanda, false);
}

void get_bevanda_servita_info(struct bevanda_stato *bevandaServita)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("~~~~~~~~  Fornisci i dati della bevanda da segnare come servita  ~~~~~~~~\n");
    get_input("Inserisci l'id della bevanda: ", NUM_LEN, str, false);
    bevandaServita->idBevanda = strtoul(str, &ptr, 10);
    get_input("Inserisci il numero della comanda: ", NUM_LEN, str, false);
    bevandaServita->comanda = strtoul(str,&ptr, 10);
}

void get_plus_bevanda_servita_info(struct bevanda_stato *bevandaServita)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    printf("~~~~~~~~  Fornisci i dati della bevanda appartenente alla comanda %u da segnare come servita  ~~~~~~~~\n\n", bevandaServita->comanda);
    get_input("Inserisci l'id della bevanda: ", NUM_LEN, str, false);
    bevandaServita->idBevanda = strtoul(str, &ptr, 10);
}

void get_pizza_effettiva_info(struct pizza_effettiva *pizzaEffettiva)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("~~~~~~~~  Fornisci i dati richiesta per l'ordinazione di una pizza  ~~~~~~~~\n");
    get_input("Inserisci il numero della comanda: ", NUM_LEN, str, false);
    pizzaEffettiva->comanda = strtoul(str, &ptr, 10);
    get_input("Inserisci il nome della pizza: ", NOME_PRODOTTO_LEN, pizzaEffettiva->nomePizza, false);
}

void get_plus_pizza_effettiva_info(struct pizza_effettiva *pizzaEffettiva)
{
    clear_screen();
    printf("~~~~~~~~~~  Fornisci i dati della pizza da aggiungere alla comanda %u  ~~~~~~~~~~\n\n", pizzaEffettiva->comanda);
    get_input("Inserisci il nome della pizza: ", NOME_PRODOTTO_LEN, pizzaEffettiva->nomePizza, false);
}

void get_pizza_servita_info(struct pizza_stato *pizzaServita)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("~~~~~~~~  Fornisci i dati della pizza da segnare come servita  ~~~~~~~~\n");
    get_input("Inserisci l'id della pizza: ", NUM_LEN, str, false);
    pizzaServita->idPizza = strtoul(str, &ptr, 10);
    get_input("Inserisci il numero della comanda: ", NUM_LEN, str, false);
    pizzaServita->comanda = strtoul(str,&ptr, 10);
}

void get_plus_pizza_servita_info(struct pizza_stato *pizzaServita)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    printf("~~~~~~~~  Fornisci i dati della pizza appartenente alla comanda %u da segnare come servita  ~~~~~~~~\n\n", pizzaServita->comanda);
    get_input("Inserisci l'id della pizza: ", NUM_LEN, str, false);
    pizzaServita->idPizza = strtoul(str, &ptr, 10);
}

void get_ingrediente_aggiunta_info(char ingrediente[NOME_PRODOTTO_LEN])
{
    puts("\n\n\n~~~~~~~~   Fornisci i dati dell'ingrediente da usare come aggiunta   ~~~~~~~\n");
    get_input("Inserisci il nome dell'ingrediente: ", NOME_PRODOTTO_LEN, ingrediente, false);
}

void print_tavoli_occupati(struct lista_tavoli *listaTavoliOccupati)
{
    clear_screen();
    puts("~~~~~~~~~~~~~~   Tavoli occupati   ~~~~~~~~~~~~~~\n");

    for (size_t i = 0; i < listaTavoliOccupati->num_entries; ++i) {
        printf("Numero tavolo:  %u\n", listaTavoliOccupati->tavolo[i].numeroTavolo);
    }
}

void print_tavoli_comandeServite(struct lista_tavoli *listaTavoliComandeServite)
{
    clear_screen();
    puts("~~~~~~~~~~~~~~   Tavoli in cui le comande sono state completamente servite   ~~~~~~~~~~~~~~\n");

    for (size_t i = 0; i < listaTavoliComandeServite->num_entries; i++) {
        printf("Numero tavolo:  %u\n", listaTavoliComandeServite->tavolo[i].numeroTavolo);
    }
}


void print_cose_da_servire(struct da_servire *daServire)
{
    clear_screen();
    puts("~~~~~~~~~~~~~~~~   Prodotti da servire   ~~~~~~~~~~~~~~~");
    size_t j;

    for (size_t i = 0; i < daServire->num_comande; i++) {
        puts("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        printf("SERVIRE AL TAVOLO: %u\t(comanda: %u)\n", daServire->comandeDaServire[i].tavolo, daServire->comandeDaServire[i].comanda);
        puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        j = 0;
        while (j + 1 < daServire->comandeDaServire[i].num_prodotti && daServire->comandeDaServire[i].prodottiDaServire[j].id < daServire->comandeDaServire[i].prodottiDaServire[j+1].id) {
            printf("\t~~ %s\t(id: %u)\n", daServire->comandeDaServire[i].prodottiDaServire[j].nome, daServire->comandeDaServire[i].prodottiDaServire[j].id);
            j++;
        }
        printf("\t~~ %s\t(id: %u)\n", daServire->comandeDaServire[i].prodottiDaServire[j].nome,daServire->comandeDaServire[i].prodottiDaServire[j].id);
        j++;

        if(j < daServire->comandeDaServire[i].num_prodotti)
            puts("\t_________________________________\n");
        while (j  < daServire->comandeDaServire[i].num_prodotti) {
            printf("\t~~ %s\t(id: %u)\n", daServire->comandeDaServire[i].prodottiDaServire[j].nome, daServire->comandeDaServire[i].prodottiDaServire[j].id);
            j++;
        }
        puts("\n");
    }
}
