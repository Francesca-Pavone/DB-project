#pragma once
#include <stdbool.h>
#include <stdlib.h>

extern bool init_db(void);
extern void fini_db(void);

#define DATE_LEN 11
#define TIME_LEN 3
#define DATETIME_LEN 20

#define USERNAME_LEN 91
#define PASSWORD_LEN 45
struct credentials {
	char username[USERNAME_LEN];
	char password[PASSWORD_LEN];
};

typedef enum {
	LOGIN_ROLE,
	MANAGER,
	CAMERIERE,
    PIZZAIOLO,
    BARISTA,
	FAILED_LOGIN
} role_t;

extern void db_switch_to_login(void);
extern role_t attempt_login(struct credentials *cred);

extern void db_switch_to_manager(void);
extern void db_switch_to_cameriere(void);
extern void db_switch_to_pizzaiolo(void);
extern void db_switch_to_barista(void);


#define NOME_TURNO_LEN 45
struct turno {
    char nome[NOME_TURNO_LEN];
    char oraInizio[TIME_LEN];
    char oraFine[TIME_LEN];
};
extern void do_crea_turno(struct turno *turno);


#define NOME_CAMERIERE_LEN 45
#define COGNOME_CAMERIERE_LEN 45
struct turno_cameriere {
    char nomeC[NOME_CAMERIERE_LEN];
    char cognomeC[COGNOME_CAMERIERE_LEN];
    char turno[NOME_TURNO_LEN];
    char data[DATE_LEN];
};
extern bool do_crea_turno_cameriere(struct turno_cameriere *turnoCameriere);
extern void do_cancella_turno_cameriere(struct turno_cameriere *turnoCameriere);


struct turno_tavolo {
    unsigned int tavolo;
    char turno[NOME_TURNO_LEN];
    char data[DATE_LEN];
};
extern bool do_crea_turno_tavolo(struct turno_tavolo *turnoTavolo);


struct cameriere_tavolo {
    char nomeC[NOME_CAMERIERE_LEN];
    char cognomeC[COGNOME_CAMERIERE_LEN];
    unsigned int tavolo;
};
extern bool do_associa_cameriere_tavolo(struct cameriere_tavolo *cameriereTavolo);
extern void do_togli_cameriere_tavolo(struct cameriere_tavolo *cameriereTavolo);


#define NOME_CLIENTE_LEN 45
#define COGNOME_CLIENTE_LEN 45
struct cliente {
    char nome[NOME_CLIENTE_LEN];
    char cognome[COGNOME_CLIENTE_LEN];
    unsigned int numeroCommensali;
};
extern int do_registra_cliente(struct cliente *cliente);


#define NOME_PRODOTTO_LEN 45
#define PREZZO_PIZZA_LEN 6
struct pizza {
    char nome[NOME_PRODOTTO_LEN];
    char prezzo[PREZZO_PIZZA_LEN];
};
extern void do_inserisci_pizza_menu(struct pizza *pizza);


#define PREZZO_INGREDIENTE_LEN 5
struct ingrediente {
    char nome[NOME_PRODOTTO_LEN];
    char prezzo[PREZZO_INGREDIENTE_LEN];
};
extern void do_inserisci_ingrediente_menu(struct ingrediente *ingrediente);


struct condimento {
    char pizza[NOME_PRODOTTO_LEN];
    char ingrediente[NOME_PRODOTTO_LEN];
};
extern bool do_inserisci_condimento_pizza(struct condimento *condimento);


#define PREZZO_BEVANDA_LEN 7
struct bevanda {
    char nome[NOME_PRODOTTO_LEN];
    char prezzo[PREZZO_BEVANDA_LEN];
};
extern void do_inserisci_bevanda_menu(struct bevanda *bevanda);


struct prodotto_quantita {
    char nome[NOME_PRODOTTO_LEN];
    unsigned int quantita;
};
extern void do_aggiorna_quantita_ingrediente(struct prodotto_quantita *ingredienteQuantita);
extern void do_aggiorna_quantita_bevanda(struct prodotto_quantita *bevandaQuantita);


struct tavolo {
  unsigned int numeroTavolo;
};
extern int do_registra_comanda(struct tavolo *tavolo, char *username);


#define PREZZO_SCONTRINO_LEN 8
struct scontrino {
    char prezzo[PREZZO_SCONTRINO_LEN];
    char id[DATETIME_LEN];
};
extern struct scontrino *do_stampa_scontrino(struct tavolo *tavolo);
extern void do_registra_pagamento_scontrino(struct scontrino *scontrino);


#define ENTRATE_LEN 10
struct entrata {
    char tot[ENTRATE_LEN];
};
struct anno_mese {
    short int anno;
    unsigned int mese;
};
extern struct entrata *do_visualizza_entrata_mensile(struct anno_mese *annoMese);
extern struct entrata *do_visualizza_entrata_giornaliera(char giorno[DATE_LEN]);


struct  nuovo_tavolo {
    unsigned int numeroTavolo;
    unsigned int numeroPosti;
};
extern void do_inserisci_tavolo(struct nuovo_tavolo *nuovoTavolo);


struct nuovo_cameriere {
    char nome[NOME_CAMERIERE_LEN];
    char cognome[COGNOME_CAMERIERE_LEN];
};
extern void do_inserisci_cameriere(struct nuovo_cameriere *nuovoCameriere);


struct lista_tavoli {
    unsigned int num_entries;
    struct tavolo tavolo[];
};
extern struct lista_tavoli *do_visualizza_tavoli_occupati(char *username);
extern struct lista_tavoli *do_visualizza_tavoli_comande_servite(char *username);


struct prodotto_da_servire {
    unsigned int id;
    char nome[NOME_PRODOTTO_LEN];
};
struct comande_da_servire {
    unsigned int comanda;
    unsigned int tavolo;
    size_t num_prodotti;
    struct prodotto_da_servire *prodottiDaServire;
};
struct da_servire {
    size_t num_comande;
    struct comande_da_servire comandeDaServire[];
};
extern struct da_servire *do_visualizza_cosa_e_dove_servire(char *username);
extern void free_da_servire(struct da_servire *daServire);


struct bevanda_effettiva {
    char nomeBevanda[NOME_PRODOTTO_LEN];
    unsigned int comanda;
};
extern bool do_ordina_bevanda(struct bevanda_effettiva *bevandaEffettiva, char *username);


struct bevanda_stato {
    unsigned int idBevanda;
    unsigned int comanda;
};
extern bool do_segna_bevanda_servita(struct bevanda_stato *bevandaServita, char *username);
extern bool do_segna_bevanda_pronta(struct bevanda_stato *bevandaPronta);


struct pizza_effettiva {
    char nomePizza[NOME_PRODOTTO_LEN];
    unsigned int comanda;
};
extern int do_ordina_pizza(struct pizza_effettiva *pizzaEffettiva, char *username);


struct aggiunta_pizza {
    unsigned int idPizza;
    unsigned int comanda;
    char ingrediente[NOME_PRODOTTO_LEN];
};
extern void do_inserisci_aggiunta_pizza(struct aggiunta_pizza *aggiunta);


struct pizza_stato {
    unsigned int idPizza;
    unsigned int comanda;
};
extern void do_segna_pizza_ordinata(struct pizza_stato *pizzaOrdinata);
extern bool do_segna_pizza_servita(struct pizza_stato *pizzaServita, char *username);
extern bool do_segna_pizza_pronta(struct pizza_stato *pizzaPronta);


struct aggiunta {
    char ingrediente[NOME_PRODOTTO_LEN];
};
struct pizza_info {
    unsigned int comanda;
    unsigned int idPizza;
    char nomePizza[NOME_PRODOTTO_LEN];
    size_t num_aggiunte;
    struct aggiunta *aggiunte;
};
struct pizze_da_preparare {
    size_t num_pizze;
    struct pizza_info pizzaInfo[];
};
extern struct pizze_da_preparare *do_visualizza_pizze_da_preparare(void);
extern void free_pizze_da_preparare(struct pizze_da_preparare *pizzeDaPreparare);


struct bevanda_da_preparare {
    unsigned int comanda;
    unsigned int idBevanda;
    char nomeBevanda[NOME_PRODOTTO_LEN];
};
struct lista_bevande_da_preparare {
    unsigned int num_entries;
    struct bevanda_da_preparare bevandaDaPreparare[];
};
extern struct lista_bevande_da_preparare *do_visualizza_bevande_da_preparare(void);





