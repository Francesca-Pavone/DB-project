#pragma  once
#include "../model/db.h"

enum actions {
    VISUALIZZA_BEVANDE_DA_PREPARARE, //e prendi in carico
    SEGNA_BEVANDA_PRONTA,
    QUIT,
    END_OF_ACTIONS
};

extern int get_barista_action(void);

extern void get_bevanda_pronta_info(struct bevanda_stato *bevandaPronta);
extern void get_plus_bevanda_pronta_info(struct bevanda_stato *bevandaPronta);

extern void print_bevande_da_preparare(struct lista_bevande_da_preparare *listaBevandeDaPreparare);