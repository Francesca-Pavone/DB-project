#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <setjmp.h>
#include <termios.h>


#include "io.h"

jmp_buf leave_buff;
bool io_initialized;

static void leave(void)
{
	if(io_initialized)
		longjmp(leave_buff, 1);
	else
		exit(EXIT_SUCCESS);
}


char *get_input(char *question, int len, char *buff, bool hide)
{
	printf("%s", question);


	struct termios term, oterm;

	if(hide) {
		fflush(stdout);
		if (tcgetattr(fileno(stdin), &oterm) == 0) {
			memcpy(&term, &oterm, sizeof(struct termios));
			term.c_lflag &= ~(ECHO|ECHONL);
			tcsetattr(fileno(stdin), TCSAFLUSH, &term);
		} else {
			memset(&term, 0, sizeof(struct termios));
			memset(&oterm, 0, sizeof(struct termios));
		}
	}

	if(fgets(buff, len, stdin) != NULL) {
		buff[strcspn(buff, "\n")] = 0;
	} else {
		printf("EOF received, leaving...\n");
		fflush(stdout);
		leave();
	}

	// Empty stdin
	if(strlen(buff) + 1 == len) {
		int ch;
		while(((ch = getchar()) != EOF) && (ch != '\n'));
		if(ch == EOF) {
			printf("EOF received, leaving...\n");
			fflush(stdout);
			leave();
		}
	}
    if(hide) {
		fwrite("\n", 1, 1, stdout);
		tcsetattr(fileno(stdin), TCSAFLUSH, &oterm);
	}

	return buff;
}



 char *get_choice(unsigned int len, char *choice)
{
    char c;
    unsigned int i;

    // Acquisisce da tastiera al più len - 1 caratteri
    for(i = 0; i < len; i++) {
        (void) fread(&c, sizeof(char), 1, stdin);
        if(c == '\n') {
            choice[i] = '\0';
            break;
        } else
            choice[i] = c;
    }

    // Controlla che il terminatore di stringa sia stato inserito
    if(i == len - 1)
        choice[i] = '\0';

    // Se sono stati digitati più caratteri, svuota il buffer della tastiera
    if(strlen(choice) >= len) {
        // Svuota il buffer della tastiera
        do {
            c = (char)getchar();
        } while (c != '\n');
    }

    return choice;
}


bool yes_or_no(char *question, char yes, char no, bool default_answer, bool insensitive)
{
	int extra;

	// yes and no characters should be lowercase by default
	yes = (char)tolower(yes);
	no = (char)tolower(no);

	// Which of the two is the default?
	char s, n;
	if(default_answer) {
		s = (char)toupper(yes);
		n = no;
	} else {
		s = yes;
		n = (char)toupper(no);
	}

	while(true) {
		printf("%s [%c/%c]: ", question, s, n);
		extra = 0;

		char c = (char)getchar();
		char ch = 0;
		if(c != '\n') {
			while(((ch = (char)getchar()) != EOF) && (ch != '\n'))
				extra++;
		}
		if(c == EOF || ch == EOF) {
			printf("EOF received, leaving...\n");
			fflush(stdout);
			leave();
		}
		if(extra > 0)
			continue;

		// Check the answer
		if(c == '\n') {
			return default_answer;
		} else if(c == yes) {
			return true;
		} else if(c == no) {
			return false;
		} else if(c == toupper(yes)) {
			if(default_answer || insensitive) return true;
		} else if(c == toupper(no)) {
			if(!default_answer || insensitive) return false;
		}
	}
}


int multi_choice(char *question, char *options[], int num)
{
    int i = 0, j = 0, len = 0;

    while(i<num)
        len += (int)strlen(options[i++]);

    char *possibilities = (char *) malloc(len * num * sizeof(char *));

    for(i = 0; i < num; i++) {
        for(int z=0; z<(int)strlen(options[i]); z++) {
            possibilities[j++] = options[i][z];
        }
        possibilities[j++] = '/';
    }
    possibilities[j-1] = '\0';

    while(true) {
        printf("%s [%s]: ", question, possibilities);

        char c[5];
        sprintf(c, "%s", get_choice(5, c));

        if(strlen(c) > 2)
            continue;

        for (i = 0; i < num; i++) {
            if (strcmp(c, options[i]) == 0) {
                return i;
            }
        }
    }

}


void clear_screen(void)
{
	printf("\033[2J\033[H");
}


void press_anykey(void)
{
	char c;
	puts("\nPremi enter per continuare...");
	while((c = (char)getchar()) != '\n');
	(void)c;
}
