#pragma once

extern void barista_controller(void);