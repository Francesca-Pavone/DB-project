#pragma once
#include "../model/db.h"

extern void cameriere_controller(struct credentials *credentials );