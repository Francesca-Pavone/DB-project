#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "manager.h"
#include "../model/db.h"
#include "../view/manager.h"
#include "../utils/io.h"

static bool crea_turno(void)
{
    struct turno turno;
    memset(&turno, 0, sizeof(turno));
    get_creazione_turno_info(&turno);
    do_crea_turno(&turno);
    return false;
}

static bool plus_crea_turno_cameriere(struct turno_cameriere turnoCameriere)
{
    bool go;
    while (true) {
        go = yes_or_no("\n\nDesideri far lavorare un altro cameriere in questo turno e in questa data?", 's', 'n', false, true);
        if (go) {
            get_plus1_creazione_turno_cameriere_info(&turnoCameriere);
            do_crea_turno_cameriere(&turnoCameriere);
        } else {
            go = yes_or_no("\n\nDesideri definire quali camerieri far lavorare in un altro turno di questo giorno?",
                           's', 'n', false, true);
            if(go){
                get_plus2_creazione_turno_cameriere_info(&turnoCameriere);
                do_crea_turno_cameriere(&turnoCameriere);
            } else
                return false;
        }
    }
}

static bool crea_turno_cameriere(void)
{
    struct turno_cameriere turnoCameriere;
    memset(&turnoCameriere, 0, sizeof(turnoCameriere));
    get_creazione_turno_cameriere_info(&turnoCameriere);
    bool done = do_crea_turno_cameriere(&turnoCameriere);
    if(done)
        plus_crea_turno_cameriere(turnoCameriere);
    return false;
}

static bool plus_crea_turno_tavolo(struct turno_tavolo turnoTavolo)
{
    while (true) {
        bool go = yes_or_no("\n\nDesideri utilizzare un altro tavolo in questo turno e in questa data?", 's', 'n', false, true);
        if (go) {
            get_plus1_creazione_turno_tavolo_info(&turnoTavolo);
            do_crea_turno_tavolo(&turnoTavolo);
        } else {
            go = yes_or_no("\n\nDesideri definire quali tavoli utilizzare in un altro turno di questo giorno?",
                           's', 'n', false, true);
            if(go){
                get_plus2_creazione_turno_tavolo_info(&turnoTavolo);
                do_crea_turno_tavolo(&turnoTavolo);
            } else
                return false;
        }
    }
}

static bool crea_turno_tavolo(void)
{
    struct turno_tavolo turnoTavolo;
    memset(&turnoTavolo, 0, sizeof(turnoTavolo));
    get_creazione_turno_tavolo_info(&turnoTavolo);
    bool done = do_crea_turno_tavolo(&turnoTavolo);
    if(done)
        plus_crea_turno_tavolo(turnoTavolo);
    return false;
}

static bool plus_associa_cameriere_tavolo(struct cameriere_tavolo cameriereTavolo)
{
    while (true) {
        bool go = yes_or_no("\n\nDesideri associare questo cameriere ad altri tavoli?", 's', 'n', false, true);
        if (go) {
            get_plus_associazione_cameriere_tavolo_info(&cameriereTavolo);
            do_associa_cameriere_tavolo(&cameriereTavolo);
        } else
            return false;
    }
}

static bool associa_cameriere_tavolo(void)
{
    struct cameriere_tavolo cameriereTavolo;
    memset(&cameriereTavolo, 0, sizeof(cameriereTavolo));
    get_associazione_cameriere_tavolo_info(&cameriereTavolo);
    bool done = do_associa_cameriere_tavolo(&cameriereTavolo);
    if(done)
        plus_associa_cameriere_tavolo(cameriereTavolo);
    return false;
}

static bool togli_cameriere_tavolo(void)
{
    struct cameriere_tavolo cameriereTavolo;
    memset(&cameriereTavolo, 0, sizeof(cameriereTavolo));
    get_rimozione_cameriere_tavolo_info(&cameriereTavolo);
    do_togli_cameriere_tavolo(&cameriereTavolo);
    return false;
}

static bool registra_cliente(void)
{
    int numeroTavolo;
    struct cliente cliente;
    memset(&cliente, 0, sizeof(cliente));
    get_cliente_info(&cliente);
    numeroTavolo = do_registra_cliente(&cliente);

    if(numeroTavolo >= 0) {
        printf("\nAl cliente %s %s e' stato assegnato il tavolo %d", cliente.nome, cliente.cognome, numeroTavolo);

        bool plus_actions;
        printf("\n\nSe il tavolo %d non ha un cameriere associato il cliente non potra' in seguito ordinare..", numeroTavolo);
        plus_actions = yes_or_no("\nDesideri associare un cameriere a questo tavolo o cambiarlo nel caso in cui fosse gia' associato?\n\t**Puoi farlo anche in un secondo momento\n     ", 's', 'n', false, true);
        if(plus_actions) {
            struct cameriere_tavolo cameriereTavolo;
            memset(&cameriereTavolo, 0, sizeof(cameriereTavolo));
            cameriereTavolo.tavolo = numeroTavolo;
            get_plus_registrazione_cliente_info(&cameriereTavolo);
            do_associa_cameriere_tavolo(&cameriereTavolo);
            return false;
        }
    }
    return false;
}

static bool inserisci_pizza_menu(void)
{
    struct pizza pizza;
    memset(&pizza, 0, sizeof(pizza));
    get_pizza_menu_info(&pizza);
    do_inserisci_pizza_menu(&pizza);

    while (true) {
        bool plus_actions;
        plus_actions = yes_or_no("\nDesideri inserire un'altra pizza nel menu?", 's', 'n', false, true);
        if (plus_actions) {
            get_pizza_menu_info(&pizza);
            do_inserisci_pizza_menu(&pizza);
        }
        else
            return false;
    }
}

static bool inserisci_ingrediente_menu(void)
{
    struct ingrediente ingrediente;
    memset(&ingrediente, 0, sizeof(ingrediente));
    get_ingrediente_menu_info(&ingrediente);
    do_inserisci_ingrediente_menu(&ingrediente);

    while (true) {
        bool plus_actions;
        plus_actions = yes_or_no("\nDesideri inserire un altro ingrediente nel menu?", 's', 'n', false, true);
        if (plus_actions) {
            get_ingrediente_menu_info(&ingrediente);
            do_inserisci_ingrediente_menu(&ingrediente);
        }
        else
            return false;
    }
}

static bool plus_inserisci_condimento_pizza(struct condimento condimento)
{
    while (true) {
        bool go = yes_or_no("\n\nDesideri inserire altri condimenti per questa pizza?", 's', 'n', false, true);
        if (go) {
            get_plus_pizza_condimento_info(&condimento);
            do_inserisci_condimento_pizza(&condimento);
        } else
            return false;
    }
}

static bool inserisci_condimento_pizza(void)
{
    struct condimento condimento;
    memset(&condimento, 0, sizeof(condimento));
    get_pizza_condimento_info(&condimento);
    bool done = do_inserisci_condimento_pizza(&condimento);
    if(done)
        plus_inserisci_condimento_pizza(condimento);
    return false;
}

static bool inserisci_bevanda_menu(void)
{
    struct bevanda bevanda;
    memset(&bevanda, 0, sizeof(bevanda));
    get_bevanda_menu_info(&bevanda);
    do_inserisci_bevanda_menu(&bevanda);

    while (true) {
        bool plus_actions;
        plus_actions = yes_or_no("\nDesideri inserire un'altra bevanda nel menu?", 's', 'n', false, true);
        if (plus_actions) {
            get_bevanda_menu_info(&bevanda);
            do_inserisci_bevanda_menu(&bevanda);
        }
        else
            return false;
    }
}

static bool aggiorna_quantita_ingrediente(void)
{
    struct prodotto_quantita ingredienteQuantita;
    memset(&ingredienteQuantita, 0, sizeof(ingredienteQuantita));
    get_quantita_prodotto_info(&ingredienteQuantita);
    do_aggiorna_quantita_ingrediente(&ingredienteQuantita);
    return false;
}

static bool aggiorna_quantita_bevanda(void)
{
    struct prodotto_quantita bevandaQuantita;
    memset(&bevandaQuantita, 0, sizeof(bevandaQuantita));
    get_quantita_prodotto_info(&bevandaQuantita);
    do_aggiorna_quantita_bevanda(&bevandaQuantita);
    return false;
}

static bool stampa_scontrino(void)
{
    struct tavolo tavolo;
    memset(&tavolo, 0, sizeof(tavolo));
    get_tavolo_scontrino_info(&tavolo);
    struct scontrino *scontrino = do_stampa_scontrino(&tavolo);

    if(scontrino != NULL) {
        printf("\n[%s] : scontrino del tavolo %u stampato, prezzo da pagare: %s\n", scontrino->id, tavolo.numeroTavolo, scontrino->prezzo);

        bool plus_actions;
        plus_actions = yes_or_no("\nDesideri registrare subito il pagamento di questo scontrino?", 's', 'n', false, true);
        if(plus_actions) {
            do_registra_pagamento_scontrino(scontrino);
            return false;
        }

    }
    return false;
}

static bool registra_pagamento_scontrino(void)
{
    struct scontrino scontrino;
    memset(&scontrino, 0, sizeof(scontrino));
    get_pagamento_scontrino_info(&scontrino);
    do_registra_pagamento_scontrino(&scontrino);
    return false;
}

static bool visualizza_entrata_giornaliera(void)
{
    char giorno[DATE_LEN];
    memset(&giorno, 0, DATE_LEN);
    get_giorno_info(giorno);
    struct entrata *entrataGiornaliera = do_visualizza_entrata_giornaliera(giorno);

    if(entrataGiornaliera != NULL)
        printf("\nLe entrate del giorno %s ammontano a: %s\n", giorno, entrataGiornaliera->tot);
    return false;
}

static bool visualizza_entrata_mensile(void)
{
    struct anno_mese annoMese;
    memset(&annoMese, 0, sizeof(annoMese));
    get_anno_mese_info(&annoMese);
    struct entrata *entrataMensile = do_visualizza_entrata_mensile(&annoMese);

    if(entrataMensile != NULL)
        printf("\nLe entrate del mese %u dell'anno %u ammontano a: %s\n", annoMese.mese, annoMese.anno, entrataMensile->tot);
    return false;
}

static bool inserisci_tavolo(void)
{
    struct nuovo_tavolo nuovoTavolo;
    memset(&nuovoTavolo, 0, sizeof(nuovoTavolo));
    get_tavolo_info(&nuovoTavolo);
    do_inserisci_tavolo(&nuovoTavolo);

    while (true) {
        bool plus_actions;
        plus_actions = yes_or_no("\nDesideri inserire un altro tavolo nel sistema?", 's', 'n', false, true);
        if (plus_actions) {
            get_tavolo_info(&nuovoTavolo);
            do_inserisci_tavolo(&nuovoTavolo);
        }
        else
            return false;
    }
}

static bool inserisci_cameriere(void)
{
    struct nuovo_cameriere nuovoCameriere;
    memset(&nuovoCameriere, 0, sizeof(nuovoCameriere));
    get_cameriere_info(&nuovoCameriere);
    do_inserisci_cameriere(&nuovoCameriere);

    while (true) {
        bool plus_actions;
        plus_actions = yes_or_no("\nDesideri inserire un altro cameriere nel sistema?", 's', 'n', false, true);
        if (plus_actions) {
            get_cameriere_info(&nuovoCameriere);
            do_inserisci_cameriere(&nuovoCameriere);
        }
        else
            return false;
    }
}

static bool cancella_turno_cameriere(void)
{
    struct turno_cameriere turnoCameriere;
    memset(&turnoCameriere, 0, sizeof(turnoCameriere));
    get_cancellazione_turno_cameriere_info(&turnoCameriere);
    do_cancella_turno_cameriere(&turnoCameriere);
    return false;
}

static bool quit(void) {
    return true;
}

static struct {
    enum actions action;
    bool (*control)(void);
} controls[END_OF_ACTIONS] = {
        {.action = CREA_TURNO, .control = crea_turno},
        {.action = CREA_TURNO_CAMERIERE, .control = crea_turno_cameriere},
        {.action = CREA_TURNO_TAVOLO, .control = crea_turno_tavolo},
        {.action = ASSOCIA_CAMERIERE_TAVOLO, .control = associa_cameriere_tavolo},
        {.action = TOGLI_CAMERIERE_TAVOLO, .control = togli_cameriere_tavolo},
        {.action = REGISTRA_CLIENTE, .control = registra_cliente},
        {.action = INSERISCI_PIZZA_MENU, .control = inserisci_pizza_menu},
        {.action = INSERISCI_INGREDIENTE_MENU, .control = inserisci_ingrediente_menu},
        {.action = INSERISCI_CONDIMENTO_PIZZA, .control = inserisci_condimento_pizza},
        {.action = INSERISCI_BEVANDA_MENU, .control = inserisci_bevanda_menu},
        {.action = AGGIORNA_QUANTITA_INGREDIENTE, .control = aggiorna_quantita_ingrediente},
        {.action = AGGIORNA_QUANTITA_BEVANDA, .control = aggiorna_quantita_bevanda},
        {.action = STAMPA_SCONTRINO, .control = stampa_scontrino},
        {.action = REGISTRA_PAGAMENTO_SCONTRINO, .control = registra_pagamento_scontrino},
        {.action = VISUALIZZA_ENTRATA_GIORNALIERA, .control = visualizza_entrata_giornaliera},
        {.action = VISUALIZZA_ENTRATA_MENSILE, .control = visualizza_entrata_mensile},
        {.action = INSERISCI_TAVOLO, .control = inserisci_tavolo},
        {.action = INSERISCI_CAMERIERE, .control = inserisci_cameriere},
        {.action = CANCELLA_TURNO_CAMERIERE, .control = cancella_turno_cameriere},
        {.action = QUIT, .control = quit}
};

void manager_controller(void)
{
    db_switch_to_manager();

    while(true) {
        int action = get_manager_action();
        if (action >= END_OF_ACTIONS) {
            fprintf(stderr, "Errore: azione non riconosciuta\n");
            continue;
        }
        if (controls[action].control())
            break;

        press_anykey();
    }
}