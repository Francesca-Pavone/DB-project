#pragma once
#include "../model/db.h"

enum actions {
    VISUALIZZA_PIZZE_DA_PREPARARE, //e prendi in carico
    SEGNA_PIZZA_PRONTA,
    QUIT,
    END_OF_ACTIONS
};


extern int get_pizzaiolo_action(void);

extern void get_pizza_pronta_info(struct pizza_stato *pizzaPronta);
extern void get_plus_pizza_pronta_info(struct pizza_stato *pizzaPronta);

extern void print_pizze_da_preparare(struct pizze_da_preparare *pizzeDaPreparare);