#include <stdbool.h>

#include "login.h"
#include "manager.h"
#include "cameriere.h"
#include "pizzaiolo.h"
#include "barista.h"
#include "../view/login.h"


bool login(void)
{
	struct credentials cred;
	view_login(&cred);
	role_t role = attempt_login(&cred);

	switch(role) {
		case MANAGER:
            manager_controller();
			break;
		case CAMERIERE:
            cameriere_controller(&cred);
			break;
        case PIZZAIOLO:
            pizzaiolo_controller();
            break;
        case BARISTA:
            barista_controller();
            break;
		default:
			return false;
	}

	return true;
}
