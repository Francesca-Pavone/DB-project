#include <stdio.h>

#include "pizzaiolo.h"
#include "../utils/io.h"
#include "../utils/validation.h"

#define NUM_LEN 5


int get_pizzaiolo_action(void)
{
    char *options[] = {"1", "2", "3"};

    clear_screen();
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    puts("|                                                               |");
    puts("|                    SCHERMATA DEL PIZZAIOLO                    |");
    puts("|                                                               |");
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    puts("~~~~~~~~~~~~~~   Che azione desideri effettuare?   ~~~~~~~~~~~~~~\n");
    puts("1) Visualizzare le pizze da preparare e prenderle in carico");
    puts("2) Segnare che una pizza e' pronta per essere servita");
    puts("3) Quit");

    return multi_choice("\nScegli un'opzione", options, 3);
}


void get_pizza_pronta_info(struct pizza_stato *pizzaPronta)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("~~~~~~~~  Fornisci i dati della pizza da segnare come pronta  ~~~~~~~~\n");
    get_input("Inserisci l'id della pizza: ", NUM_LEN, str, false);
    pizzaPronta->idPizza = strtoul(str, &ptr, 10);
    get_input("Inserisci il numero della comanda: ", NUM_LEN, str, false);
    pizzaPronta->comanda = strtoul(str,&ptr, 10);

}

void get_plus_pizza_pronta_info(struct pizza_stato *pizzaPronta)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    printf("~~~~~~~~  Fornisci i dati della pizza appartenente alla comanda %u da segnare come pronta  ~~~~~~~~\n\n", pizzaPronta->comanda);
    get_input("Inserisci l'id della pizza: ", NUM_LEN, str, false);
    pizzaPronta->idPizza = strtoul(str, &ptr, 10);

}


void print_pizze_da_preparare(struct pizze_da_preparare *pizzeDaPreparare)
{
    clear_screen();
    puts("~~~~~~~~~~~~~~~   Pizze da preparare   ~~~~~~~~~~~~~~");

    for (size_t i = 0; i < pizzeDaPreparare->num_pizze; i++) {
        printf("\n\nPIZZA: %s\t(comanda: %u,  id: %u)\n", pizzeDaPreparare->pizzaInfo[i].nomePizza, pizzeDaPreparare->pizzaInfo[i].comanda, pizzeDaPreparare->pizzaInfo[i].idPizza);

        for (size_t j = 0; j < pizzeDaPreparare->pizzaInfo[i].num_aggiunte; j++) {
            printf("\t~~ AGGIUNTA: %s\n", pizzeDaPreparare->pizzaInfo[i].aggiunte[j].ingrediente);
        }
        puts("____________________________________________________");
    }
}