#include <stdio.h>

#include "login.h"
#include "../utils/io.h"

void view_login(struct credentials *cred)
{
	clear_screen();
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    puts("|                                                               |");
    puts("|              SISTEMA DI GESTIONE DELLA PIZZERIA               |");
    puts("|                                                               |");
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	get_input("Username: ", USERNAME_LEN, cred->username, false);
	get_input("Password: ", PASSWORD_LEN, cred->password, true);
}

bool ask_for_relogin(void)
{
	return yes_or_no("Vuoi effettuare il login con un altro utente?", 's', 'n', false, true);
}
