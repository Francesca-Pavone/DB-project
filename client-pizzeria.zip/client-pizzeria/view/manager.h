#pragma  once
#include "../model/db.h"

enum actions {
    CREA_TURNO,
    CREA_TURNO_CAMERIERE,
    CREA_TURNO_TAVOLO,
    ASSOCIA_CAMERIERE_TAVOLO,
    TOGLI_CAMERIERE_TAVOLO,
    REGISTRA_CLIENTE,
    INSERISCI_PIZZA_MENU,
    INSERISCI_INGREDIENTE_MENU,
    INSERISCI_CONDIMENTO_PIZZA,
    INSERISCI_BEVANDA_MENU,
    AGGIORNA_QUANTITA_INGREDIENTE,
    AGGIORNA_QUANTITA_BEVANDA,
    STAMPA_SCONTRINO,
    REGISTRA_PAGAMENTO_SCONTRINO,
    VISUALIZZA_ENTRATA_GIORNALIERA,
    VISUALIZZA_ENTRATA_MENSILE,
    INSERISCI_TAVOLO,
    INSERISCI_CAMERIERE,
    CANCELLA_TURNO_CAMERIERE,
    QUIT,
    END_OF_ACTIONS
};


extern int get_manager_action(void);
extern void get_creazione_turno_info(struct turno *turno);
extern void get_creazione_turno_cameriere_info(struct turno_cameriere *turnoCameriere);
extern void get_plus1_creazione_turno_cameriere_info(struct turno_cameriere *turnoCameriere);
extern void get_plus2_creazione_turno_cameriere_info(struct turno_cameriere *turnoCameriere);
extern void get_creazione_turno_tavolo_info(struct turno_tavolo *turnoTavolo);
extern void get_plus1_creazione_turno_tavolo_info(struct turno_tavolo *turnoTavolo);
extern void get_plus2_creazione_turno_tavolo_info(struct turno_tavolo *turnoTavolo);
extern void get_associazione_cameriere_tavolo_info(struct cameriere_tavolo *cameriereTavolo);
extern void get_plus_associazione_cameriere_tavolo_info(struct cameriere_tavolo *cameriereTavolo);
extern void get_rimozione_cameriere_tavolo_info(struct cameriere_tavolo *cameriereTavolo);
extern void get_cliente_info(struct cliente *cliente);
extern void get_pizza_menu_info(struct  pizza *pizza);
extern void get_ingrediente_menu_info(struct  ingrediente *ingrediente);
extern void get_pizza_condimento_info(struct condimento *condimento);
extern void get_plus_pizza_condimento_info(struct condimento *condimento);
extern void get_bevanda_menu_info(struct bevanda *bevanda);
extern void get_plus_registrazione_cliente_info(struct cameriere_tavolo *cameriereTavolo);
extern void get_quantita_prodotto_info(struct prodotto_quantita *ingredienteQuantita);
extern void get_tavolo_scontrino_info(struct tavolo *tavolo);
extern void get_pagamento_scontrino_info(struct scontrino *scontrino);
extern void get_giorno_info(char giorno[DATE_LEN]);
extern void get_anno_mese_info(struct anno_mese *annoMese);
extern void get_cameriere_info(struct nuovo_cameriere *nuovoCameriere);
extern void get_tavolo_info(struct nuovo_tavolo *nuovoTavolo);
extern void get_cancellazione_turno_cameriere_info(struct turno_cameriere *turnoCameriere);

