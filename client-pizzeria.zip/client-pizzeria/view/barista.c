#include <stdio.h>

#include "barista.h"
#include "../utils/io.h"
#include "../utils/validation.h"

#define NUM_LEN 5

int get_barista_action(void)
{
    char *options[] = {"1", "2", "3"};

    clear_screen();
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    puts("|                                                               |");
    puts("|                     SCHERMATA DEL BARISTA                     |");
    puts("|                                                               |");
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    puts("~~~~~~~~~~~~~~   Che azione desideri effettuare?   ~~~~~~~~~~~~~~\n");
    puts("1) Visualizzare le bevande da preparare e prenderle in carico");
    puts("2) Segnare che una bevanda e' pronta per essere servita");
    puts("3) Quit");

    return multi_choice("\nScegli un'opzione", options, 3);
}

void get_bevanda_pronta_info(struct bevanda_stato *bevandaPronta)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("~~~~~~~~  Fornisci i dati della bevanda da segnare come pronta  ~~~~~~~~\n");
    get_input("Inserisci l'id della bevanda: ", NUM_LEN, str, false);
    bevandaPronta->idBevanda = strtoul(str, &ptr, 10);
    get_input("Inserisci il numero della comanda: ", NUM_LEN, str, false);
    bevandaPronta->comanda = strtoul(str,&ptr, 10);
}

void get_plus_bevanda_pronta_info(struct bevanda_stato *bevandaPronta)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    printf("~~~~~~~~  Fornisci i dati della bevanda appartenente alla comanda %u da segnare come pronta  ~~~~~~~~\n\n", bevandaPronta->comanda);
    get_input("Inserisci l'id della bevanda: ", NUM_LEN, str, false);
    bevandaPronta->idBevanda = strtoul(str, &ptr, 10);

}

void print_bevande_da_preparare(struct lista_bevande_da_preparare *listaBevandeDaPreparare)
{
    clear_screen();
    puts("~~~~~~~~~~~~~~   Bevande da preparare   ~~~~~~~~~~~~~~\n");
    for (size_t i = 0; i < listaBevandeDaPreparare->num_entries; i++) {
        printf("\n~~ BEVANDA: %s\t(comanda: %u,  id: %u)\n", listaBevandeDaPreparare->bevandaDaPreparare[i].nomeBevanda, listaBevandeDaPreparare->bevandaDaPreparare[i].comanda, listaBevandeDaPreparare->bevandaDaPreparare[i].idBevanda);
    }
}