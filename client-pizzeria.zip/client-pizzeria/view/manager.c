#include <stdio.h>

#include "manager.h"
#include "../utils/io.h"
#include "../utils/validation.h"

#define NUM_LEN 10

int get_manager_action(void)
{
    char *options[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"};

    clear_screen();
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    puts("|                                                               |");
    puts("|                     SCHERMATA DEL MANAGER                     |");
    puts("|                                                               |");
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    puts("~~~~~~~~~~~~~~   Che azione desideri effettuare?   ~~~~~~~~~~~~~~\n");
    puts("1)  Creare un turno e definire la sua fascia oraria");
    puts("2)  Definire in che turno far lavorare un cameriere");
    puts("3)  Definire in che turno usare un tavolo");
    puts("4)  Associare un cameriere ad un tavolo");
    puts("5)  Togliere un tavolo ad un cameriere");
    puts("6)  Registrare un cliente e assegnargli un tavolo");
    puts("7)  Inserire nel menu una nuova pizza");
    puts("8)  Inserire nel menu un nuovo ingrediente da usare come aggiunta e/o condimento");
    puts("9)  Indicare un ingrediente usato per condire una pizza");
    puts("10) Inserire nel menu una nuova bevanda");
    puts("11) Aggiornare la quantita presente in magazzino di un ingrediente");
    puts("12) Aggiornare la quantita presente in magazzino di una bevanda");
    puts("13) Stampare uno scontrino");
    puts("14) Registrare il pagamento di uno scontrino");
    puts("15) Visualizzare le entrate di una giornata");
    puts("16) Visualizzare le entrate di un mese");
    puts("17) Inserisci un nuovo tavolo nel sistema");
    puts("18) Inserisci un nuovo cameriere nel sistema");
    puts("19) Segnalare che un cameriere non e' presente nel suo turno di lavoro");
    puts("20) Quit");

    return multi_choice("\nScegli un'opzione", options, 20);
}


void get_creazione_turno_info(struct turno *turno)
{
    clear_screen();
    puts("\n~~~~~~~~~~~~   Fornisci i dati richiesti per creare un nuovo turno   ~~~~~~~~~~~~\n");
    get_input("Inserisci il nome che vuoi dare al turno: ", NOME_TURNO_LEN, turno->nome, false);
    puts("\n*** Usare il formato [HH] per gli orari ***\n");

    while (true) {
        get_input("Inserisci l'orario di inizio del turno: ", TIME_LEN, turno->oraInizio, false);
        if(validate_time(turno->oraInizio))
            break;
        fprintf(stderr, "Formato non valido, reinserire l'orario\n");
    }

    while (true) {
        get_input("Inserisci l'orario di fine del turno: ", TIME_LEN, turno->oraFine, false);
        if(validate_time(turno->oraFine))
            break;
        fprintf(stderr, "Formato non valido, reinserire l'orario\n");
    }

}


void get_creazione_turno_cameriere_info(struct turno_cameriere *turnoCameriere)
{
    clear_screen();
    puts("\n~~~~~~   Fornisci i dati richiesti per definire in che turno far lavorare un cameriere   ~~~~~\n");
    get_input("Inserisci il nome del cameriere: ", NOME_CAMERIERE_LEN, turnoCameriere->nomeC, false);
    get_input("Inserisci il cognome del cameriere: ", COGNOME_CAMERIERE_LEN, turnoCameriere->cognomeC, false);
    get_input("Inserisci il turno: ", NOME_TURNO_LEN, turnoCameriere->turno, false);

    while (true) {
        get_input("Inserisci la data [YYYY-MM-DD]: ", DATE_LEN, turnoCameriere->data, false);
        if(validate_date(turnoCameriere->data))
            break;
        fprintf(stderr, "Formato non valido, reinserire la data\n");
    }

}

void get_plus1_creazione_turno_cameriere_info(struct turno_cameriere *turnoCameriere)
{
    clear_screen();
    printf("\n~~~~~~   Fornisci i dati del cameriere da far lavorare nel turno di '%s' in data %s   ~~~~~\n\n", turnoCameriere->turno, turnoCameriere->data);
    get_input("Inserisci il nome del cameriere: ", NOME_CAMERIERE_LEN, turnoCameriere->nomeC, false);
    get_input("Inserisci il cognome del cameriere: ", COGNOME_CAMERIERE_LEN, turnoCameriere->cognomeC, false);

}

void get_plus2_creazione_turno_cameriere_info(struct turno_cameriere *turnoCameriere)
{
    clear_screen();
    printf("\n~~~~~~   Fornisci i dati richiesti per definire in che turno del giorno '%s' far lavorare un cameriere   ~~~~~\n\n", turnoCameriere->data);
    get_input("Inserisci il turno: ", NOME_TURNO_LEN, turnoCameriere->turno, false);
    get_input("Inserisci il nome del cameriere: ", NOME_CAMERIERE_LEN, turnoCameriere->nomeC, false);
    get_input("Inserisci il cognome del cameriere: ", COGNOME_CAMERIERE_LEN, turnoCameriere->cognomeC, false);

}

void get_creazione_turno_tavolo_info(struct turno_tavolo *turnoTavolo)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci i dati richiesti per definire in che turno usare un tavolo   ~~~~~~~~~~\n");
    get_input("Inserisci il numero del tavolo: ", NUM_LEN, str, false);
    turnoTavolo->tavolo = strtoul(str, &ptr, 10);      //per ottenere un unsigned int
    get_input("Inserisci il turno: ", NOME_TURNO_LEN, turnoTavolo->turno, false);

    while (true) {
        get_input("Inserisci la data [YYYY-MM-DD]: ", DATE_LEN, turnoTavolo->data, false);
        if(validate_date(turnoTavolo->data))
            break;
        fprintf(stderr, "Formato non valido, reinserire la data\n");
    }
}

void get_plus1_creazione_turno_tavolo_info(struct turno_tavolo *turnoTavolo)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    printf("\n~~~~~~~~~~~   Fornisci i dati del tavolo da utilizzare nel turno di '%s' in data %s   ~~~~~~~~~~\n\n", turnoTavolo->turno, turnoTavolo->data);
    get_input("Inserisci il numero del tavolo: ", NUM_LEN, str, false);
    turnoTavolo->tavolo = strtoul(str, &ptr, 10);
}

void get_plus2_creazione_turno_tavolo_info(struct turno_tavolo *turnoTavolo)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    printf("\n~~~~~~~~~~~   Fornisci i dati richiesti per definire in che turno del giorno '%s' utilizzare un tavolo   ~~~~~~~~~~\n\n", turnoTavolo->data);
    get_input("Inserisci il turno: ", NOME_TURNO_LEN, turnoTavolo->turno, false);
    get_input("Inserisci il numero del tavolo: ", NUM_LEN, str, false);
    turnoTavolo->tavolo = strtoul(str, &ptr, 10);
}

void get_associazione_cameriere_tavolo_info(struct cameriere_tavolo *cameriereTavolo)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci i dati richiesti per associare un cameriere ad un tavolo   ~~~~~~~~~~\n");
    get_input("Inserisci il numero del tavolo: ", NUM_LEN, str, false);
    cameriereTavolo->tavolo = strtoul(str, &ptr, 10);
    get_input("Inserisci il nome del cameriere: ", NOME_CAMERIERE_LEN, cameriereTavolo->nomeC, false);
    get_input("Inserisci il cognome del cameriere: ", COGNOME_CAMERIERE_LEN, cameriereTavolo->cognomeC, false);

}

extern void get_plus_associazione_cameriere_tavolo_info(struct cameriere_tavolo *cameriereTavolo)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    printf("\n~~~~~~~~~~~   Fornisci i dati richiesti per associare il cameriere '%s %s' ad un altro tavolo   ~~~~~~~~~~\n\n", cameriereTavolo->nomeC, cameriereTavolo->cognomeC);
    get_input("Inserisci il numero del tavolo: ", NUM_LEN, str, false);
    cameriereTavolo->tavolo = strtoul(str, &ptr, 10);
}

void get_rimozione_cameriere_tavolo_info(struct cameriere_tavolo *cameriereTavolo)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci i dati richiesti per togliere un tavolo ad un cameriere   ~~~~~~~~~~\n");
    get_input("Inserisci il nome del cameriere: ", NOME_CAMERIERE_LEN, cameriereTavolo->nomeC, false);
    get_input("Inserisci il cognome del cameriere: ", COGNOME_CAMERIERE_LEN, cameriereTavolo->cognomeC, false);
    get_input("Inserisci il numero del tavolo: ", NUM_LEN, str, false);
    cameriereTavolo->tavolo = strtoul(str, &ptr, 10);
}

void get_cliente_info(struct cliente *cliente)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci i dati del cliente da registrare   ~~~~~~~~~~\n");
    get_input("Inserisci il nome del cliente: ", NOME_CLIENTE_LEN, cliente->nome, false);
    get_input("Inserisci il cognome del cliente: ", COGNOME_CLIENTE_LEN, cliente->cognome, false);
    get_input("Inserisci il numero di commensali: ", NUM_LEN, str, false);
    cliente->numeroCommensali = strtoul(str, &ptr, 10);

}

void get_plus_registrazione_cliente_info(struct cameriere_tavolo *cameriereTavolo)
{
    clear_screen();
    printf("\n~~~~~~~~~~~   Fornisci i dati del cameriere che desideri associare al tavolo %u   ~~~~~~~~~~\n\n", cameriereTavolo->tavolo);
    get_input("Inserisci il nome del cameriere: ", NOME_CAMERIERE_LEN, cameriereTavolo->nomeC, false);
    get_input("Inserisci il cognome del cameriere: ", COGNOME_CAMERIERE_LEN, cameriereTavolo->cognomeC, false);

}

void get_pizza_menu_info(struct pizza *pizza)
{
    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci le informazioni sulla pizza da inserire nel menu   ~~~~~~~~~~\n");
    get_input("Inserisci il nome della pizza: ", NOME_PRODOTTO_LEN, pizza->nome, false);
    get_input("Inserisci il prezzo della pizza: ", PREZZO_PIZZA_LEN, pizza->prezzo, false);
}

void get_ingrediente_menu_info(struct ingrediente *ingrediente)
{
    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci le informazioni sull'ingrediente da inserire nel menu   ~~~~~~~~~~\n");
    get_input("Inserisci il nome dell'ingrediente: ", NOME_PRODOTTO_LEN, ingrediente->nome, false);
    get_input("Inserisci il prezzo dell'ingrediente: ", PREZZO_PIZZA_LEN, ingrediente->prezzo, false);
}

void get_pizza_condimento_info(struct condimento *condimento)
{
    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci le informazioni sulla pizza e sull'ingrediente da usare come condimento  ~~~~~~~~~~\n");
    get_input("Inserisci il nome della pizza: ", NOME_PRODOTTO_LEN, condimento->pizza, false);
    get_input("Inserisci il nome dell'ingrediente: ", NOME_PRODOTTO_LEN, condimento->ingrediente, false);
}

void get_plus_pizza_condimento_info(struct condimento *condimento)
{
    clear_screen();
    printf("\n~~~~~~~~~~~   Fornisci le informazioni sull'ingrediente da usare come condimento per la pizza %s  ~~~~~~~~~~\n\n", condimento->pizza);
    get_input("Inserisci il nome dell'ingrediente: ", NOME_PRODOTTO_LEN, condimento->ingrediente, false);

}


void get_bevanda_menu_info(struct bevanda *bevanda)
{
    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci le informazioni sulla bevanda da inserire nel menu   ~~~~~~~~~~\n");
    get_input("Inserisci il nome della bevanda: ", NOME_PRODOTTO_LEN, bevanda->nome, false);
    get_input("Inserisci il prezzo della bevanda: ", PREZZO_PIZZA_LEN, bevanda->prezzo, false);
}

void get_quantita_prodotto_info(struct prodotto_quantita *prodottoQuantita)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci i dati richiesti per aggiornare la quantita'   ~~~~~~~~~~\n");
    get_input("Inserisci il nome del prodotto: ", NOME_PRODOTTO_LEN, prodottoQuantita->nome, false);
    get_input("Inserisci la quantita' che vuoi aggiungere: ", NUM_LEN, str, false);
    prodottoQuantita->quantita = strtoul(str, &ptr, 10);
}

void get_tavolo_scontrino_info(struct tavolo *tavolo)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci i dati richiesti per la stampa dello scontrino   ~~~~~~~~~~\n");
    get_input("Inserisci il numero del tavolo: ", NUM_LEN, str, false);
    tavolo->numeroTavolo = strtoul(str, &ptr, 10);
}

void get_pagamento_scontrino_info(struct scontrino *scontrino)
{
    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci i dati richiesti per il pagamento dello scontrino   ~~~~~~~~~~\n");
    get_input("Inserisci la data e l'ora in cui e' stato stampato lo scontrino [YYYY-MM-DD HH:MM:SS]: ", DATETIME_LEN, scontrino->id, false);
}

void get_giorno_info(char giorno[DATE_LEN]) {
    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci i dati richiesti per la visualizzazione delle entrate giornaliere   ~~~~~~~~~~\n");
    while (true) {
        get_input("Inserisci la data [YYYY-MM-DD]: ", DATE_LEN, giorno, false);
        if (validate_date(giorno))
            break;
        fprintf(stderr, "Formato non valido, reinserire la data\n");
    }
}

void get_anno_mese_info(struct anno_mese *annoMese)
{
    char str[NUM_LEN];

    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci i dati richiesti per la visualizzazione delle entrate mensili   ~~~~~~~~~~\n");
    get_input("Inserisci l'anno [YYYY]: ", NUM_LEN, str, false);
    annoMese->anno = strtol(str, NULL, 10);
    while (true){
        get_input("Inserisci il mese [MM]: ", NUM_LEN, str, false);
        annoMese->mese = strtoul(str, NULL, 10);
        if(annoMese->mese >= 1 && annoMese->mese <= 12)
            break;
        fprintf(stderr, "Formato non valido, reinserire il mese\n");
    }
}


void get_tavolo_info(struct nuovo_tavolo *nuovoTavolo)
{
    char str[NUM_LEN];
    char *ptr;

    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci i dati richiesti per inserire un nuovo tavolo   ~~~~~~~~~~\n");

    get_input("Inserisci il numero del tavolo: ", NUM_LEN, str, false);
    nuovoTavolo->numeroTavolo = strtoul(str, &ptr, 10);
    get_input("Inserisci il numero di posti che il tavolo mette a disposizione: ", NUM_LEN, str, false);
    nuovoTavolo->numeroPosti = strtoul(str, &ptr, 10);
}

void get_cameriere_info(struct nuovo_cameriere *nuovoCameriere)
{
    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci i dati richiesti per inserire un nuovo cameriere   ~~~~~~~~~~\n");
    get_input("Inserisci il nome del cameriere: ", NOME_CAMERIERE_LEN, nuovoCameriere->nome, false);
    get_input("Inserisci il cognome del cameriere: ", COGNOME_CAMERIERE_LEN, nuovoCameriere->cognome, false);

}

void get_cancellazione_turno_cameriere_info(struct turno_cameriere *turnoCameriere)
{
    clear_screen();
    puts("\n~~~~~~~~~~~   Fornisci i dati richiesti per cancellare il turno di un cameriere   ~~~~~~~~~~\n");
    get_input("Inserisci il nome del cameriere: ", NOME_CAMERIERE_LEN, turnoCameriere->nomeC, false);
    get_input("Inserisci il cognome del cameriere: ", COGNOME_CAMERIERE_LEN, turnoCameriere->cognomeC, false);
    get_input("Inserisci il turno: ", NOME_TURNO_LEN, turnoCameriere->turno, false);

    while (true) {
        get_input("Inserisci la data [YYYY-MM-DD]: ", DATE_LEN, turnoCameriere->data, false);
        if(validate_date(turnoCameriere->data))
            break;
        fprintf(stderr, "Formato non valido, reinserire la data\n");
    }
}