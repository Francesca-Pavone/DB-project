#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "barista.h"
#include "../model/db.h"
#include "../view/barista.h"
#include "../utils/io.h"

static bool visualizza_bevande_da_preparare(void)
{
    struct lista_bevande_da_preparare *bevandeDaPreparare = do_visualizza_bevande_da_preparare();
    if(bevandeDaPreparare != NULL) {
        print_bevande_da_preparare(bevandeDaPreparare);
        free(bevandeDaPreparare);
    }
    return false;
}

static bool segna_bevanda_pronta(void)
{

    bool done;
    struct bevanda_stato bevandaPronta;
    memset(&bevandaPronta, 0, sizeof(bevandaPronta));
    get_bevanda_pronta_info(&bevandaPronta);
    done = do_segna_bevanda_pronta(&bevandaPronta);

    bool plus_actions;
    while (done) {
        plus_actions = yes_or_no("\nDesideri segnare come servite altre bevande di questa comanda?", 's', 'n', false, true);
        if (plus_actions) {
            get_plus_bevanda_pronta_info(&bevandaPronta);
            done = do_segna_bevanda_pronta(&bevandaPronta);
        }else
            return false;
    }
    return false;
}

static bool quit(void) {
    return true;
}

static struct {
    enum actions action;
    bool (*control)(void);
} controls[END_OF_ACTIONS] = {
        {.action = VISUALIZZA_BEVANDE_DA_PREPARARE, .control = visualizza_bevande_da_preparare},
        {.action = SEGNA_BEVANDA_PRONTA, .control = segna_bevanda_pronta},
        {.action = QUIT, .control = quit},
};


void barista_controller(void)
{
    db_switch_to_barista();

    while (true) {
        int action = get_barista_action();
        if(action >= END_OF_ACTIONS) {
            fprintf(stderr, "Errore: azione non riconosciuta\n");
            continue;
        }
        if (controls[action].control())
            break;
        press_anykey();
    }
}