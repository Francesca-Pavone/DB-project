#pragma  once
#include "../model/db.h"

enum actions {
    VISUALIZZA_TAVOLI_OCCUPATI,
    VISUALIZZA_TAVOLI_COMANDE_SERVITE,
    REGISTRA_COMANDA,
    VISUALIZZA_COSA_E_DOVE_SERVIRE,
    ORDINA_PIZZA,
    ORDINA_BEVANDA,
    SEGNA_PIZZA_SERVITA,
    SEGNA_BEVANDA_SERVITA,
    QUIT,
    END_OF_ACTIONS
};



extern int get_cameriere_action(void);
extern int get_ordinazione_info(void);

extern void get_registrazione_comanda_info(struct tavolo *numeroTavolo);
extern void get_bevanda_effettiva_info(struct bevanda_effettiva *bevandaEffettiva);
extern void get_plus_bevanda_effettiva_info(struct bevanda_effettiva *bevandaEffettiva);
extern void get_bevanda_servita_info(struct bevanda_stato *bevandaServita);
extern void get_plus_bevanda_servita_info(struct bevanda_stato *bevandaServita);
extern void get_pizza_effettiva_info(struct pizza_effettiva *pizzaEffettiva);
extern void get_plus_pizza_effettiva_info(struct pizza_effettiva *pizzaEffettiva);
extern void get_pizza_servita_info(struct pizza_stato *pizzaServita);
extern void get_plus_pizza_servita_info(struct pizza_stato *pizzaServita);
extern void get_ingrediente_aggiunta_info(char ingrediente[NOME_PRODOTTO_LEN]);

extern void print_tavoli_occupati(struct lista_tavoli *listaTavoliOccupati);
extern void print_tavoli_comandeServite(struct lista_tavoli *listaTavoliComandeServite);
extern void print_cose_da_servire(struct da_servire *daServire);
