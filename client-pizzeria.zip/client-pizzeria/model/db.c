#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <mysql.h>
#include <assert.h>

#include "db.h"
#include "../utils/db.h"

static MYSQL *conn;

static MYSQL_STMT *login_procedure;

//MANAGER
static MYSQL_STMT *crea_turno;
static MYSQL_STMT *crea_turno_cameriere;
static MYSQL_STMT *crea_turno_tavolo;
static MYSQL_STMT *associa_cameriere_tavolo;
static MYSQL_STMT *togli_cameriere_tavolo;
static MYSQL_STMT *registra_cliente;
static MYSQL_STMT *inserisci_pizza_menu;
static MYSQL_STMT *inserisci_ingrediente_menu;
static MYSQL_STMT *inserisci_condimento_pizza;
static MYSQL_STMT *inserisci_bevanda_menu;
static MYSQL_STMT *aggiorna_quantita_ingrediente;
static MYSQL_STMT *aggiorna_quantita_bevanda;
static MYSQL_STMT *stampa_scontrino;
static MYSQL_STMT *registra_pagamento_scontrino;
static MYSQL_STMT *visualizza_entrata_giornaliera;
static MYSQL_STMT *visualizza_entrata_mensile;
static MYSQL_STMT *inserisci_tavolo;
static MYSQL_STMT *inserisci_cameriere;
static MYSQL_STMT *cancella_turno_cameriere;

//CAMERIERE
static MYSQL_STMT *visualizza_tavoli_occupati;
static MYSQL_STMT *visualizza_tavoli_comande_servite;
static MYSQL_STMT *registra_comanda;
static MYSQL_STMT *visualizza_cosa_e_dove_servire;
static MYSQL_STMT *ordina_pizza;
static MYSQL_STMT *inserisci_aggiunta_pizza;
static MYSQL_STMT *segna_pizza_ordinata;
static MYSQL_STMT *ordina_bevanda;
static MYSQL_STMT *segna_pizza_servita;
static MYSQL_STMT *segna_bevanda_servita;

//PIZZAIOLO
static MYSQL_STMT *visualizza_pizze_da_preparare;
static MYSQL_STMT *segna_pizza_pronta;

//BARISTA
static MYSQL_STMT *visualizza_bevande_da_preparare;
static MYSQL_STMT *segna_bevanda_pronta;


static void close_prepared_stmts(void)
{
	if(login_procedure) {
		mysql_stmt_close(login_procedure);
		login_procedure = NULL;
	}

    //MANAGER
    if(crea_turno) {
        mysql_stmt_close(crea_turno);
        crea_turno = NULL;
    }
    if(crea_turno_cameriere) {
        mysql_stmt_close(crea_turno_cameriere);
        crea_turno_cameriere = NULL;
    }
    if(crea_turno_tavolo) {
        mysql_stmt_close(crea_turno_tavolo);
        crea_turno_tavolo = NULL;
    }
    if(associa_cameriere_tavolo) {
        mysql_stmt_close(associa_cameriere_tavolo);
        associa_cameriere_tavolo = NULL;
    }
    if(togli_cameriere_tavolo) {
        mysql_stmt_close(togli_cameriere_tavolo);
        togli_cameriere_tavolo = NULL;
    }
    if(registra_cliente) {
        mysql_stmt_close(registra_cliente);
        registra_cliente = NULL;
    }
    if(inserisci_pizza_menu) {
        mysql_stmt_close(inserisci_pizza_menu);
        inserisci_pizza_menu = NULL;
    }
    if(inserisci_ingrediente_menu) {
        mysql_stmt_close(inserisci_ingrediente_menu);
        inserisci_ingrediente_menu = NULL;
    }
    if(inserisci_condimento_pizza) {
        mysql_stmt_close(inserisci_condimento_pizza);
        inserisci_condimento_pizza = NULL;
    }
    if(inserisci_bevanda_menu) {
        mysql_stmt_close(inserisci_bevanda_menu);
        inserisci_bevanda_menu = NULL;
    }
    if(aggiorna_quantita_ingrediente) {
        mysql_stmt_close(aggiorna_quantita_ingrediente);
        aggiorna_quantita_ingrediente = NULL;
    }
    if(aggiorna_quantita_bevanda) {
        mysql_stmt_close(aggiorna_quantita_bevanda);
        aggiorna_quantita_bevanda = NULL;
    }
    if(stampa_scontrino) {
        mysql_stmt_close(stampa_scontrino);
        stampa_scontrino = NULL;
    }
    if(registra_pagamento_scontrino) {
        mysql_stmt_close(registra_pagamento_scontrino);
        registra_pagamento_scontrino = NULL;
    }
    if(visualizza_entrata_giornaliera) {
        mysql_stmt_close(visualizza_entrata_giornaliera);
        visualizza_entrata_giornaliera = NULL;
    }
    if(visualizza_entrata_mensile) {
        mysql_stmt_close(visualizza_entrata_mensile);
        visualizza_entrata_mensile = NULL;
    }
    if(inserisci_tavolo) {
        mysql_stmt_close(inserisci_tavolo);
        inserisci_tavolo = NULL;
    }
    if(inserisci_cameriere) {
        mysql_stmt_close(inserisci_cameriere);
        inserisci_cameriere = NULL;
    }
    if(cancella_turno_cameriere) {
        mysql_stmt_close(cancella_turno_cameriere);
        cancella_turno_cameriere = NULL;
    }

    //CAMERIERE
    if(visualizza_tavoli_occupati) {
        mysql_stmt_close(visualizza_tavoli_occupati);
        visualizza_tavoli_occupati = NULL;
    }
    if(visualizza_tavoli_comande_servite) {
        mysql_stmt_close(visualizza_tavoli_comande_servite);
        visualizza_tavoli_comande_servite = NULL;
    }
    if(registra_comanda) {
        mysql_stmt_close(registra_comanda);
        registra_comanda = NULL;
    }
    if(visualizza_cosa_e_dove_servire) {
        mysql_stmt_close(visualizza_cosa_e_dove_servire);
        visualizza_cosa_e_dove_servire = NULL;
    }
    if(ordina_pizza) {
        mysql_stmt_close(ordina_pizza);
        ordina_pizza = NULL;
    }
    if(inserisci_aggiunta_pizza) {
        mysql_stmt_close(inserisci_aggiunta_pizza);
        inserisci_aggiunta_pizza = NULL;
    }
    if(segna_pizza_ordinata) {
        mysql_stmt_close(segna_pizza_ordinata);
        segna_pizza_ordinata = NULL;
    }
    if(ordina_bevanda) {
        mysql_stmt_close(ordina_bevanda);
        ordina_bevanda = NULL;
    }
    if(segna_pizza_servita) {
        mysql_stmt_close(segna_pizza_servita);
        segna_pizza_servita = NULL;
    }
    if(segna_bevanda_servita) {
        mysql_stmt_close(segna_bevanda_servita);
        segna_bevanda_servita = NULL;
    }

    //PIZZAIOLO
    if(visualizza_pizze_da_preparare) {
        mysql_stmt_close(visualizza_pizze_da_preparare);
        visualizza_pizze_da_preparare = NULL;
    }
    if(segna_pizza_pronta) {
        mysql_stmt_close(segna_pizza_pronta);
        segna_pizza_pronta = NULL;
    }


    //BARISTA
    if(visualizza_bevande_da_preparare) {
        mysql_stmt_close(visualizza_bevande_da_preparare);
        visualizza_bevande_da_preparare = NULL;
    }
    if(segna_bevanda_pronta) {
        mysql_stmt_close(segna_bevanda_pronta);
        segna_bevanda_pronta = NULL;
    }

}


static bool initialize_prepared_stmts(role_t for_role)
{
	switch(for_role) {

		case LOGIN_ROLE:
			if(!setup_prepared_stmt(&login_procedure, "call login(?, ?, ?)", conn)) {
				print_stmt_error(login_procedure, "Impossibile inizilaizzare lo statement di login\n");
				return false;
			}
			break;

		case MANAGER:
			if(!setup_prepared_stmt(&crea_turno, "call crea_turno(?, ?, ?)", conn)) {
				print_stmt_error(crea_turno, "Impossibile inizilaizzare lo statement di creazione di un turno\n");
				return false;
			}
            if(!setup_prepared_stmt(&crea_turno_cameriere, "call crea_turno_cameriere(?, ?, ?, ?)", conn)) {
                print_stmt_error(crea_turno_cameriere, "Impossibile inizilaizzare lo statement di creazione del turno di un cameriere\n");
                return false;
            }
            if(!setup_prepared_stmt(&crea_turno_tavolo, "call crea_turno_tavolo(?, ?, ?)", conn)) {
                print_stmt_error(crea_turno_tavolo, "Impossibile inizilaizzare lo statement di creazione del turno di un tavolo\n");
                return false;
            }
            if(!setup_prepared_stmt(&associa_cameriere_tavolo, "call associa_cameriere_tavolo(?, ?, ?)", conn)) {
                print_stmt_error(associa_cameriere_tavolo, "Impossibile inizilaizzare lo statement di associazione di un cameriere ad un tavolo\n");
                return false;
            }
            if(!setup_prepared_stmt(&togli_cameriere_tavolo, "call togli_cameriere_tavolo(?, ?, ?)", conn)) {
                print_stmt_error(togli_cameriere_tavolo, "Impossibile inizilaizzare lo statement di rimozione di un tavolo ad un cameriere\n");
                return false;
            }
            if(!setup_prepared_stmt(&registra_cliente, "call registra_cliente(?, ?, ?, ?)", conn)) {
                print_stmt_error(registra_cliente, "Impossibile inizilaizzare lo statement di registrazione di un cliente\n");
                return false;
            }
            if(!setup_prepared_stmt(&inserisci_pizza_menu, "call inserisci_pizza_menu(?, ?)", conn)) {
                print_stmt_error(inserisci_pizza_menu, "Impossibile inizilaizzare lo statement di inserimento di una pizza nel menu\n");
                return false;
            }
            if(!setup_prepared_stmt(&inserisci_ingrediente_menu, "call inserisci_ingrediente_menu(?, ?)", conn)) {
                print_stmt_error(inserisci_ingrediente_menu, "Impossibile inizilaizzare lo statement di inserimento di un ingrediente nel menu\n");
                return false;
            }
            if(!setup_prepared_stmt(&inserisci_condimento_pizza, "call inserisci_condimento_pizza(?, ?)", conn)) {
                print_stmt_error(inserisci_condimento_pizza, "Impossibile inizilaizzare lo statement di inserimento di un condimento di una pizza\n");
                return false;
            }
            if(!setup_prepared_stmt(&inserisci_bevanda_menu, "call inserisci_bevanda_menu(?, ?)", conn)) {
                print_stmt_error(inserisci_bevanda_menu, "Impossibile inizilaizzare lo statement di inserimento di una bevanda nel menu\n");
                return false;
            }
            if(!setup_prepared_stmt(&aggiorna_quantita_ingrediente, "call aggiorna_quantita_ingrediente(?, ?)", conn)) {
                print_stmt_error(aggiorna_quantita_ingrediente, "Impossibile inizilaizzare lo statement di aggiornamneto della quantita' di un ingrediente\n");
                return false;
            }
            if(!setup_prepared_stmt(&aggiorna_quantita_bevanda, "call aggiorna_quantita_bevanda(?, ?)", conn)) {
                print_stmt_error(aggiorna_quantita_bevanda, "Impossibile inizilaizzare lo statement di aggiornamneto della quantita' di una bevanda\n");
                return false;
            }
            if(!setup_prepared_stmt(&stampa_scontrino, "call stampa_scontrino(?, ?, ?)", conn)) {
                print_stmt_error(stampa_scontrino, "Impossibile inizilaizzare lo statement di stampa di uno scontrino\n");
                return false;
            }
            if(!setup_prepared_stmt(&registra_pagamento_scontrino, "call registra_pagamento_scontrino(?)", conn)) {
                print_stmt_error(registra_pagamento_scontrino, "Impossibile inizilaizzare lo statement di registrazione del pagamento di uno scontrino\n");
                return false;
            }
            if(!setup_prepared_stmt(&visualizza_entrata_giornaliera, "call visualizza_entrata_giornaliera(?, ?)", conn)) {
                print_stmt_error(visualizza_entrata_giornaliera, "Impossibile inizilaizzare lo statement di visualizzazione delle entrate di una giornata\n");
                return false;
            }
            if(!setup_prepared_stmt(&visualizza_entrata_mensile, "call visualizza_entrata_mensile(?, ?, ?)", conn)) {
                print_stmt_error(visualizza_entrata_mensile, "Impossibile inizilaizzare lo statement di visualizzazione delle entrate di un mese\n");
                return false;
            }
            if(!setup_prepared_stmt(&inserisci_tavolo, "call inserisci_tavolo(?, ?)", conn)) {
                print_stmt_error(inserisci_tavolo, "Impossibile inizilaizzare lo statement di inserimento di un nuovo tavolo\n");
                return false;
            }
            if(!setup_prepared_stmt(&inserisci_cameriere, "call inserisci_cameriere(?, ?)", conn)) {
                print_stmt_error(inserisci_cameriere, "Impossibile inizilaizzare lo statement di inserimento di un nuovo cameriere\n");
                return false;
            }
            if(!setup_prepared_stmt(&cancella_turno_cameriere, "call cancella_turno_cameriere(?, ?, ?, ?)", conn)) {
                print_stmt_error(cancella_turno_cameriere, "Impossibile inizilaizzare lo statement di inserimento di un nuovo cameriere\n");
                return false;
            }
			break;

		case CAMERIERE:
			if(!setup_prepared_stmt(&visualizza_tavoli_occupati, "call visualizza_tavoli_occupati(?)", conn)) {
				print_stmt_error(visualizza_tavoli_occupati, "Impossibile inizilaizzare lo statement di visualizzazione dei tavoli occupati\n");
				return false;
			}
            if(!setup_prepared_stmt(&visualizza_tavoli_comande_servite, "call visualizza_tavoli_comande_servite(?)", conn)) {
                print_stmt_error(visualizza_tavoli_comande_servite, "Impossibile inizilaizzare lo statement di visualizzazione dei tavoli in cui le comande sono state completamente servite\n");
                return false;
            }
            if(!setup_prepared_stmt(&registra_comanda, "call registra_comanda(?, ?, ?)", conn)) {
                print_stmt_error(registra_comanda, "Impossibile inizilaizzare lo statement di registrazione di una comanda\n");
                return false;
            }
            if(!setup_prepared_stmt(&visualizza_cosa_e_dove_servire, "call visualizza_cosa_e_dove_servire(?)", conn)) {
                print_stmt_error(visualizza_cosa_e_dove_servire, "Impossibile inizilaizzare lo statement di visualizzazione di cosa servire e in che tavolo\n");
                return false;
            }
            if(!setup_prepared_stmt(&ordina_pizza, "call ordina_pizza(?, ?, ?, ?)", conn)) {
                print_stmt_error(ordina_pizza, "Impossibile inizilaizzare lo statement di ordinazione di una pizza\n");
                return false;
            }
            if(!setup_prepared_stmt(&inserisci_aggiunta_pizza, "call inserisci_aggiunta_pizza(?, ?, ?)", conn)) {
                print_stmt_error(inserisci_aggiunta_pizza, "Impossibile inizilaizzare lo statement di inseirimento di un'aggiunta_pizza ad una pizza\n");
                return false;
            }
            if(!setup_prepared_stmt(&segna_pizza_ordinata, "call segna_pizza_ordinata(?, ?)", conn)) {
                print_stmt_error(segna_pizza_ordinata, "Impossibile inizilaizzare lo statement per segnare una pizza come ordinata\n");
                return false;
            }
            if(!setup_prepared_stmt(&ordina_bevanda, "call ordina_bevanda(?, ?, ?)", conn)) {
                print_stmt_error(ordina_bevanda, "Impossibile inizilaizzare lo statement di ordinazione di una bevanda\n");
                return false;
            }
            if(!setup_prepared_stmt(&segna_pizza_servita, "call segna_pizza_servita(?, ?, ?)", conn)) {
                print_stmt_error(segna_pizza_servita, "Impossibile inizilaizzare lo statement per segnare una pizza come servita\n");
                return false;
            }
            if(!setup_prepared_stmt(&segna_bevanda_servita, "call segna_bevanda_servita(?, ?, ?)", conn)) {
                print_stmt_error(segna_bevanda_servita, "Impossibile inizilaizzare lo statement per segnare una bevanda come servita\n");
                return false;
            }
            break;

        case PIZZAIOLO:
            if(!setup_prepared_stmt(&visualizza_pizze_da_preparare, "call visualizza_pizze_da_preparare()", conn)) {
                print_stmt_error(visualizza_pizze_da_preparare, "Impossibile inizilaizzare lo statement di visualizzazione delle pizze da preparare\n");
                return false;
            }
            if(!setup_prepared_stmt(&segna_pizza_pronta, "call segna_pizza_pronta(?, ?)", conn)) {
                print_stmt_error(segna_pizza_pronta, "Impossibile inizilaizzare lo statement per segnare una pizza come pronta\n");
                return false;
            }
            break;

        case BARISTA:
            if(!setup_prepared_stmt(&visualizza_bevande_da_preparare, "call visualizza_bevande_da_preparare()", conn)) {
                print_stmt_error(visualizza_bevande_da_preparare, "Impossibile inizilaizzare lo statement di visualizzazione delle bevande da preparare\n");
                return false;
            }
            if(!setup_prepared_stmt(&segna_bevanda_pronta, "call segna_bevanda_pronta(?, ?)", conn)) {
                print_stmt_error(segna_bevanda_pronta, "Impossibile inizilaizzare lo statement per segnare una bevanda come pronta\n");
                return false;
            }
            break;

		default:
			fprintf(stderr, "[FATAL] Unexpected role to prepare statements.\n");
			exit(EXIT_FAILURE);
	}

	return true;
}

bool init_db(void)
{
	unsigned int timeout = 300;
	bool reconnect = true;

	conn = mysql_init(NULL);
	if(conn == NULL) {
		finish_with_error(conn, "mysql_init() failed (probably out of memory)\n");
	}

	if(mysql_real_connect(conn, getenv("HOST"), getenv("LOGIN_USER"), getenv("LOGIN_PASS"), getenv("DB"),
			      atoi(getenv("PORT")), NULL,
			      CLIENT_MULTI_STATEMENTS | CLIENT_MULTI_RESULTS | CLIENT_COMPRESS | CLIENT_INTERACTIVE | CLIENT_REMEMBER_OPTIONS) == NULL) {
		finish_with_error(conn, "mysql_real_connect() failed\n");
	}

	if (mysql_options(conn, MYSQL_OPT_CONNECT_TIMEOUT, &timeout)) {
		print_error(conn, "[mysql_options] failed.");
	}
	if(mysql_options(conn, MYSQL_OPT_RECONNECT, &reconnect)) {
		print_error(conn, "[mysql_options] failed.");
	}
#ifndef NDEBUG
	mysql_debug("d:t:O,/tmp/client.trace");
	if(mysql_dump_debug_info(conn)) {
		print_error(conn, "[debug_info] failed.");
	}
#endif

	return initialize_prepared_stmts(LOGIN_ROLE);
}


void fini_db(void)
{
	close_prepared_stmts();

	mysql_close(conn);
}


role_t attempt_login(struct credentials *cred)
{
	MYSQL_BIND param[3]; // Used both for input and output
	int role = 0;

	// Prepare parameters
	set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, cred->username, strlen(cred->username));
	set_binding_param(&param[1], MYSQL_TYPE_VAR_STRING, cred->password, strlen(cred->password));
	set_binding_param(&param[2], MYSQL_TYPE_LONG, &role, sizeof(role));

	if(mysql_stmt_bind_param(login_procedure, param) != 0) { // Note _param
		print_stmt_error(login_procedure, "Could not bind parameters for login");
		role = FAILED_LOGIN;
		goto out;
	}

	// Run procedure
	if(mysql_stmt_execute(login_procedure) != 0) {
		print_stmt_error(login_procedure, "Could not execute login procedure");
		role = FAILED_LOGIN;
		goto out;
	}

	// Prepare output parameters
	set_binding_param(&param[0], MYSQL_TYPE_LONG, &role, sizeof(role));

	if(mysql_stmt_bind_result(login_procedure, param)) {
		print_stmt_error(login_procedure, "Could not retrieve output parameter");
		role = FAILED_LOGIN;
		goto out;
	}

	// Retrieve output parameter
	if(mysql_stmt_fetch(login_procedure)) {
		print_stmt_error(login_procedure, "Could not buffer results");
		role = FAILED_LOGIN;
		goto out;
	}

    out:
    mysql_stmt_free_result(login_procedure);
	while(mysql_stmt_next_result(login_procedure) != -1) {}
    mysql_stmt_reset(login_procedure);
	return role;
}


void db_switch_to_login(void)
{
	close_prepared_stmts();
	if(mysql_change_user(conn, getenv("LOGIN_USER"), getenv("LOGIN_PASS"), getenv("DB"))) {
		fprintf(stderr, "mysql_change_user() failed: %s\n", mysql_error(conn));
		exit(EXIT_FAILURE);
	}
	if(!initialize_prepared_stmts(LOGIN_ROLE)) {
		fprintf(stderr, "[FATAL] Cannot initialize prepared statements.\n");
		exit(EXIT_FAILURE);
	}
}

void db_switch_to_manager(void)
{
    close_prepared_stmts();
    if(mysql_change_user(conn, getenv("MANAGER_USER"), getenv("MANAGER_PASS"), getenv("DB"))) {
        fprintf(stderr, "mysql_change_user() failed: %s\n", mysql_error(conn));
        exit(EXIT_FAILURE);
    }
    if(!initialize_prepared_stmts(MANAGER)) {
        fprintf(stderr, "[FATAL] Cannot initialize prepared statements.\n");
        exit(EXIT_FAILURE);
    }
}

void db_switch_to_cameriere(void)
{
    close_prepared_stmts();
    if(mysql_change_user(conn, getenv("CAMERIERE_USER"), getenv("CAMERIERE_PASS"), getenv("DB"))) {
        fprintf(stderr, "mysql_change_user() failed: %s\n", mysql_error(conn));
        exit(EXIT_FAILURE);
    }
    if(!initialize_prepared_stmts(CAMERIERE)) {
        fprintf(stderr, "[FATAL] Cannot initialize prepared statements.\n");
        exit(EXIT_FAILURE);
    }
}

void db_switch_to_pizzaiolo(void)
{
    close_prepared_stmts();
    if(mysql_change_user(conn, getenv("PIZZAIOLO_USER"), getenv("PIZZAIOLO_PASS"), getenv("DB"))) {
        fprintf(stderr, "mysql_change_user() failed: %s\n", mysql_error(conn));
        exit(EXIT_FAILURE);
    }
    if(!initialize_prepared_stmts(PIZZAIOLO)) {
        fprintf(stderr, "[FATAL] Cannot initialize prepared statements.\n");
        exit(EXIT_FAILURE);
    }
}

void db_switch_to_barista(void)
{
    close_prepared_stmts();
    if(mysql_change_user(conn, getenv("BARISTA_USER"), getenv("BARISTA_PASS"), getenv("DB"))) {
        fprintf(stderr, "mysql_change_user() failed: %s\n", mysql_error(conn));
        exit(EXIT_FAILURE);
    }
    if(!initialize_prepared_stmts(BARISTA)) {
        fprintf(stderr, "[FATAL] Cannot initialize prepared statements.\n");
        exit(EXIT_FAILURE);
    }
}

//-------------------  MANAGER  -------------------

void do_crea_turno(struct turno *turno)
{
    MYSQL_BIND param[3];
    MYSQL_TIME oraInizio;
    MYSQL_TIME oraFine;

    //conversione dei tipi TIME mysql
    time_to_mysql_time(turno->oraInizio, &oraInizio);
    time_to_mysql_time(turno->oraFine, &oraFine);

    // bind dei parametri
    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, turno->nome, strlen(turno->nome));
    set_binding_param(&param[1], MYSQL_TYPE_TIME, &oraInizio, sizeof(oraInizio));
    set_binding_param(&param[2], MYSQL_TYPE_TIME, &oraFine, sizeof(oraFine));

    if(mysql_stmt_bind_param(crea_turno, param) != 0) {
        print_stmt_error(crea_turno, "Impossibile effettuare il binding dei parametri per do_crea_turno");
        return;
    }

    //esecuzione procedura
    if(mysql_stmt_execute(crea_turno) != 0) {
        print_stmt_error(crea_turno, "Impossibile eseguire la procedura 'crea turno'");
        return;
    }
    puts("\nTurno creato corretamente");

    mysql_stmt_free_result(crea_turno);
    mysql_stmt_reset(crea_turno);
}


bool do_crea_turno_cameriere(struct turno_cameriere *turnoCameriere)
{
    MYSQL_BIND param[4];
    MYSQL_TIME data;

    //conversione tipo data
    date_to_mysql_time(turnoCameriere->data, &data);

    // bind dei parametri
    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, turnoCameriere->nomeC, strlen(turnoCameriere->nomeC));
    set_binding_param(&param[1], MYSQL_TYPE_VAR_STRING, turnoCameriere->cognomeC, strlen(turnoCameriere->cognomeC));
    set_binding_param(&param[2], MYSQL_TYPE_VAR_STRING, turnoCameriere->turno, strlen(turnoCameriere->turno));
    set_binding_param(&param[3], MYSQL_TYPE_DATE, &data, sizeof(data));

    if(mysql_stmt_bind_param(crea_turno_cameriere, param) != 0) {
        print_stmt_error(crea_turno_cameriere, "Impossibile effettuare il binding dei parametri per do_crea_turno_cameriere");
        return false;
    }

    //esecuzione procedura
    if(mysql_stmt_execute(crea_turno_cameriere) != 0) {
        print_stmt_error(crea_turno_cameriere, "Impossibile eseguire la procedura 'crea_turno_cameriere'");
        return false;
    }
    printf("\nCreazione del turno di lavoro di %s %s eseguita correttamente\n", turnoCameriere->nomeC, turnoCameriere->cognomeC);

    mysql_stmt_free_result(crea_turno_cameriere);
    mysql_stmt_reset(crea_turno_cameriere);
    return true;
}

bool do_crea_turno_tavolo(struct turno_tavolo *turnoTavolo)
{
    MYSQL_BIND param[3];
    MYSQL_TIME data;

    date_to_mysql_time(turnoTavolo->data, &data);

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &turnoTavolo->tavolo, sizeof(turnoTavolo->tavolo));
    set_binding_param(&param[1], MYSQL_TYPE_VAR_STRING, turnoTavolo->turno, strlen(turnoTavolo->turno));
    set_binding_param(&param[2], MYSQL_TYPE_DATE, &data, sizeof(data));

    if(mysql_stmt_bind_param(crea_turno_tavolo, param) != 0) {
        print_stmt_error(crea_turno_tavolo, "Impossibile effettuare il binding dei parametri per do_crea_turno_tavolo");
        return false;
    }

    if (mysql_stmt_execute(crea_turno_tavolo) != 0) {
        print_stmt_error(crea_turno_tavolo, "Impossibile eseguire la procedura 'crea_turno_tavolo'");
        return false;
    }
    printf("\nCreazione del turno per il tavolo %u eseguita correttamente\n", turnoTavolo->tavolo);

    mysql_stmt_free_result(crea_turno_tavolo);
    mysql_stmt_reset(crea_turno_tavolo);
    return true;
}

bool do_associa_cameriere_tavolo(struct cameriere_tavolo *cameriereTavolo)
{
    MYSQL_BIND param[3];

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &cameriereTavolo->tavolo, sizeof(cameriereTavolo->tavolo));
    set_binding_param(&param[1], MYSQL_TYPE_VAR_STRING, cameriereTavolo->nomeC, strlen(cameriereTavolo->nomeC));
    set_binding_param(&param[2], MYSQL_TYPE_VAR_STRING, cameriereTavolo->cognomeC, strlen(cameriereTavolo->cognomeC));

    if(mysql_stmt_bind_param(associa_cameriere_tavolo, param) != 0) {
        print_stmt_error(associa_cameriere_tavolo, "Impossibile effettuare il binding dei parametri per do_associa_cameriere_tavolo");
        return false;
    }

    if (mysql_stmt_execute(associa_cameriere_tavolo) != 0) {
        print_stmt_error(associa_cameriere_tavolo, "Impossibile eseguire la procedura 'associa_cameriere_tavolo'");
        return false;
    }
    printf("\nIl cameriere %s %s e' stato associato al tavolo %u\n", cameriereTavolo->nomeC, cameriereTavolo->cognomeC, cameriereTavolo->tavolo);

    mysql_stmt_free_result(associa_cameriere_tavolo);
    mysql_stmt_reset(associa_cameriere_tavolo);
    return true;
}

void do_togli_cameriere_tavolo(struct cameriere_tavolo *cameriereTavolo)
{
    MYSQL_BIND param[3];

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &cameriereTavolo->tavolo, sizeof(cameriereTavolo->tavolo));
    set_binding_param(&param[1], MYSQL_TYPE_VAR_STRING, cameriereTavolo->nomeC, strlen(cameriereTavolo->nomeC));
    set_binding_param(&param[2], MYSQL_TYPE_VAR_STRING, cameriereTavolo->cognomeC, strlen(cameriereTavolo->cognomeC));

    if(mysql_stmt_bind_param(togli_cameriere_tavolo, param) != 0) {
        print_stmt_error(togli_cameriere_tavolo, "Impossibile effettuare il binding dei parametri per do_togli_cameriere_tavolo");
        return;
    }

    if (mysql_stmt_execute(togli_cameriere_tavolo) != 0) {
        print_stmt_error(togli_cameriere_tavolo, "Impossibile eseguire la procedura 'togli_cameriere_tavolo'");
        return;
    }
    printf("\nAl cameriere %s %s e' stato tolto il tavolo %u", cameriereTavolo->nomeC, cameriereTavolo->cognomeC, cameriereTavolo->tavolo);

    mysql_stmt_free_result(togli_cameriere_tavolo);
    mysql_stmt_reset(togli_cameriere_tavolo);
}

int do_registra_cliente(struct cliente *cliente)
{
    MYSQL_BIND param[4];
    int numeroTavolo;

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, cliente->nome, strlen(cliente->nome));
    set_binding_param(&param[1], MYSQL_TYPE_VAR_STRING, cliente->cognome, strlen(cliente->cognome));
    set_binding_param(&param[2], MYSQL_TYPE_LONG, &cliente->numeroCommensali, sizeof(cliente->numeroCommensali));
    set_binding_param(&param[3], MYSQL_TYPE_LONG, &numeroTavolo, sizeof(numeroTavolo));

    if (mysql_stmt_bind_param(registra_cliente, param)) {
        print_stmt_error(registra_cliente, "Impossibile effettuare il binding dei parametri per do_registra_cliente");
        numeroTavolo = -1;
        goto out;
    }

    if (mysql_stmt_execute(registra_cliente) != 0) {
        print_stmt_error(registra_cliente, "Impossibile eseguire la procedura 'registra_cliente'");
        numeroTavolo = -1;
        goto out;
    }

    //output
    set_binding_param(&param[0], MYSQL_TYPE_LONG, &numeroTavolo, sizeof(numeroTavolo));

    if(mysql_stmt_bind_result(registra_cliente, param)) {
        print_stmt_error(registra_cliente, "Impossibile recuperare i parametri di output");
        numeroTavolo = -1;
        goto out;
    }

    if(mysql_stmt_fetch(registra_cliente)) {
        print_stmt_error(registra_cliente, "Impossibile bufferizzare l'output");
        numeroTavolo = -1;
        goto out;
    }

    out:
    mysql_stmt_free_result(registra_cliente);
    while(mysql_stmt_next_result(registra_cliente) != -1) {}
    mysql_stmt_reset(registra_cliente);
    return numeroTavolo;
}

void do_inserisci_pizza_menu(struct pizza *pizza)
{
    MYSQL_BIND param[2];

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, pizza->nome, strlen(pizza->nome));
    set_binding_param(&param[1], MYSQL_TYPE_DECIMAL, pizza->prezzo, sizeof(pizza->prezzo));

    if(mysql_stmt_bind_param(inserisci_pizza_menu, param) != 0) {
        print_stmt_error(inserisci_pizza_menu, "Impossibile effettuare il binding dei parametri per do_inserisci_pizza_menu");
        return;
    }

    if (mysql_stmt_execute(inserisci_pizza_menu) != 0) {
        print_stmt_error(inserisci_pizza_menu, "Impossibile eseguire la procedura 'inserisci_pizza_menu'");
        return;
    }
    printf("\nPizza '%s' inserita nel menu\n", pizza->nome);

    mysql_stmt_free_result(inserisci_pizza_menu);
    mysql_stmt_reset(inserisci_pizza_menu);
}

void do_inserisci_ingrediente_menu(struct ingrediente *ingrediente)
{
    MYSQL_BIND param[2];

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, ingrediente->nome, strlen(ingrediente->nome));
    set_binding_param(&param[1], MYSQL_TYPE_DECIMAL, ingrediente->prezzo, sizeof(ingrediente->prezzo));

    if(mysql_stmt_bind_param(inserisci_ingrediente_menu, param) != 0) {
        print_stmt_error(inserisci_ingrediente_menu, "Impossibile effettuare il binding dei parametri per do_inserisci_ingrediente_menu");
        return;
    }

    if (mysql_stmt_execute(inserisci_ingrediente_menu) != 0) {
        print_stmt_error(inserisci_ingrediente_menu, "Impossibile eseguire la procedura 'inserisci_ingrediente_menu'");
        return;
    }
    printf("\nIngrediente '%s' inserito nel menu\n", ingrediente->nome);

    mysql_stmt_free_result(inserisci_ingrediente_menu);
    mysql_stmt_reset(inserisci_ingrediente_menu);
}

bool do_inserisci_condimento_pizza(struct condimento *condimento)
{
    MYSQL_BIND param[2];
    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, condimento->pizza, strlen(condimento->pizza));
    set_binding_param(&param[1], MYSQL_TYPE_VAR_STRING, condimento->ingrediente, strlen(condimento->ingrediente));

    if(mysql_stmt_bind_param(inserisci_condimento_pizza, param) != 0) {
        print_stmt_error(inserisci_condimento_pizza, "Impossibile effettuare il binding dei parametri per do_inserisci_condimento_pizza");
        return false;
    }

    if (mysql_stmt_execute(inserisci_condimento_pizza) != 0) {
        print_stmt_error(inserisci_condimento_pizza, "Impossibile eseguire la procedura 'inserisci_condimento_pizza'");
        return false;
    }
    printf("\nL'ingrediente '%s' e' ora usato come condimento per la pizza '%s'\n", condimento->ingrediente, condimento->pizza);

    mysql_stmt_free_result(inserisci_condimento_pizza);
    mysql_stmt_reset(inserisci_condimento_pizza);
    return true;
}

void do_inserisci_bevanda_menu(struct bevanda *bevanda)
{
    MYSQL_BIND param[2];

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, bevanda->nome, strlen(bevanda->nome));
    set_binding_param(&param[1], MYSQL_TYPE_DECIMAL, bevanda->prezzo, sizeof(bevanda->prezzo));

    if(mysql_stmt_bind_param(inserisci_bevanda_menu, param) != 0) {
        print_stmt_error(inserisci_bevanda_menu, "Impossibile effettuare il binding dei parametri per do_inserisci_bevanda_menu");
        return;
    }

    if (mysql_stmt_execute(inserisci_bevanda_menu) != 0) {
        print_stmt_error(inserisci_bevanda_menu, "Impossibile eseguire la procedura 'inserisci_bevanda_menu'");
        return;
    }
    printf("\nBevanda '%s' inserita nel menu\n", bevanda->nome);

    mysql_stmt_free_result(inserisci_bevanda_menu);
    mysql_stmt_reset(inserisci_bevanda_menu);
}

void do_aggiorna_quantita_ingrediente(struct prodotto_quantita *ingredienteQuantita)
{
    MYSQL_BIND param[2];

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, ingredienteQuantita->nome, strlen(ingredienteQuantita->nome));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &ingredienteQuantita->quantita, sizeof(ingredienteQuantita->quantita));

    if(mysql_stmt_bind_param(aggiorna_quantita_ingrediente, param) != 0) {
        print_stmt_error(aggiorna_quantita_ingrediente, "Impossibile effettuare il binding dei parametri per do_aggiorna_quantita_ingrediente");
        return;
    }

    if (mysql_stmt_execute(aggiorna_quantita_ingrediente) != 0) {
        print_stmt_error(aggiorna_quantita_ingrediente, "Impossibile eseguire la procedura 'aggiorna_quantita_ingrediente'");
        return;
    }
    printf("\nSono state aggiunte in magazzino %u unita' di %s\n", ingredienteQuantita->quantita, ingredienteQuantita->nome);

    mysql_stmt_free_result(aggiorna_quantita_ingrediente);
    mysql_stmt_reset(aggiorna_quantita_ingrediente);
}

void do_aggiorna_quantita_bevanda(struct prodotto_quantita *bevandaQuantita)
{
    MYSQL_BIND param[2];

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, bevandaQuantita->nome, strlen(bevandaQuantita->nome));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &bevandaQuantita->quantita, sizeof(bevandaQuantita->quantita));

    if(mysql_stmt_bind_param(aggiorna_quantita_bevanda, param) != 0) {
        print_stmt_error(aggiorna_quantita_bevanda, "Impossibile effettuare il binding dei parametri per do_aggiorna_quantita_bevanda");
        return;
    }

    if (mysql_stmt_execute(aggiorna_quantita_bevanda) != 0) {
        print_stmt_error(aggiorna_quantita_bevanda, "Impossibile eseguire la procedura 'aggiorna_quantita_bevanda'");
        return;
    }
    printf("\nSono state aggiunte in magazzino %u unita' di %s\n", bevandaQuantita->quantita, bevandaQuantita->nome);


    mysql_stmt_free_result(aggiorna_quantita_bevanda);
    mysql_stmt_reset(aggiorna_quantita_bevanda);
}

struct scontrino *do_stampa_scontrino(struct tavolo *tavolo)
{
    MYSQL_BIND param[3];
    MYSQL_TIME dataOra;
    char prezzo[PREZZO_SCONTRINO_LEN];
    struct scontrino *scontrino = NULL;

    init_mysql_timestamp(&dataOra);

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &tavolo->numeroTavolo, sizeof(tavolo->numeroTavolo));
    set_binding_param(&param[1], MYSQL_TYPE_DECIMAL, prezzo, strlen(prezzo));
    set_binding_param(&param[2], MYSQL_TYPE_DATETIME, &dataOra, sizeof(dataOra));

    if (mysql_stmt_bind_param(stampa_scontrino, param)) {
        print_stmt_error(stampa_scontrino, "Impossibile effettuare il binding dei parametri per do_stampa_scontrino");
        goto out;
    }

    if (mysql_stmt_execute(stampa_scontrino) != 0) {
        print_stmt_error(stampa_scontrino, "Impossibile eseguire la procedura 'stampa_scontrino'");
        goto out;
    }

    scontrino = malloc(sizeof *scontrino);
    if(scontrino == NULL)
        goto out;
    memset(scontrino, 0, sizeof(*scontrino));

    //output
    set_binding_param(&param[0], MYSQL_TYPE_DECIMAL, prezzo, PREZZO_SCONTRINO_LEN);
    set_binding_param(&param[1], MYSQL_TYPE_DATETIME, &dataOra, sizeof(dataOra));

    if(mysql_stmt_bind_result(stampa_scontrino, param)) {
        print_stmt_error(stampa_scontrino, "Impossibile recuperare i parametri di output");
        free(scontrino);
        scontrino = NULL;
        goto out;
    }

    if(mysql_stmt_fetch(stampa_scontrino)) {
        print_stmt_error(stampa_scontrino, "Impossibile bufferizzare l'output");
        goto out;
    }
    strcpy(scontrino->prezzo, prezzo);
    mysql_timestamp_to_string(&dataOra, scontrino->id);

    out:
    mysql_stmt_free_result(stampa_scontrino);
    while(mysql_stmt_next_result(stampa_scontrino) != -1) {}
    mysql_stmt_reset(stampa_scontrino);
    return scontrino;
}

void do_registra_pagamento_scontrino(struct scontrino *scontrino)
{
    MYSQL_BIND param[1];
    MYSQL_TIME dataOra;

    datetime_to_mysql_time(scontrino->id, &dataOra);
    set_binding_param(&param[0], MYSQL_TYPE_DATETIME, &dataOra, sizeof(dataOra));

    if(mysql_stmt_bind_param(registra_pagamento_scontrino, param) != 0) {
        print_stmt_error(registra_pagamento_scontrino, "Impossibile effettuare il binding dei parametri per do_registra_pagamento_scontrino");
        return;
    }

    if (mysql_stmt_execute(registra_pagamento_scontrino) != 0) {
        print_stmt_error(registra_pagamento_scontrino, "Impossibile eseguire la procedura 'registra_pagamento_scontrino'");
        return;
    }
    puts("\nIl pagamento dello scontrino e' andato a buon fine");


    mysql_stmt_free_result(registra_pagamento_scontrino);
    mysql_stmt_reset(registra_pagamento_scontrino);
}

struct entrata *do_visualizza_entrata_giornaliera(char giorno[DATE_LEN])
{
    MYSQL_BIND param[2];
    MYSQL_TIME data;
    char entrata[ENTRATE_LEN];
    struct entrata *entrataGiornaliera  = NULL;

    date_to_mysql_time(giorno, &data);

    set_binding_param(&param[0], MYSQL_TYPE_DATE, &data, sizeof(data));
    set_binding_param(&param[1], MYSQL_TYPE_DECIMAL, entrata, strlen(entrata));

    if (mysql_stmt_bind_param(visualizza_entrata_giornaliera, param)) {
        print_stmt_error(visualizza_entrata_giornaliera, "Impossibile effettuare il binding dei parametri per do_visualizza_entrata_giornaliera");
        goto out;
    }

    if (mysql_stmt_execute(visualizza_entrata_giornaliera) != 0) {
        print_stmt_error(visualizza_entrata_giornaliera, "Impossibile eseguire la procedura 'visualizza_entrata_giornaliera'");
        goto out;
    }

    entrataGiornaliera = malloc(sizeof *entrataGiornaliera);
    if(entrataGiornaliera == NULL)
        goto out;
    memset(entrataGiornaliera, 0, sizeof(*entrataGiornaliera));

    //output
    set_binding_param(&param[0], MYSQL_TYPE_DECIMAL, entrata, ENTRATE_LEN);

    if(mysql_stmt_bind_result(visualizza_entrata_giornaliera, param)) {
        print_stmt_error(visualizza_entrata_giornaliera, "Impossibile recuperare i parametri di output");
        free(entrataGiornaliera);
        entrataGiornaliera = NULL;
        goto out;
    }

    if(mysql_stmt_fetch(visualizza_entrata_giornaliera)) {
        print_stmt_error(visualizza_entrata_giornaliera, "Impossibile bufferizzare l'output");
        goto out;
    }
    strcpy(entrataGiornaliera->tot, entrata);

    out:
    mysql_stmt_free_result(visualizza_entrata_giornaliera);
    while(mysql_stmt_next_result(visualizza_entrata_giornaliera) != -1) {}
    mysql_stmt_reset(visualizza_entrata_giornaliera);
    return entrataGiornaliera;
}

struct entrata *do_visualizza_entrata_mensile(struct anno_mese *annoMese)
{
    MYSQL_BIND param[3];
    char entrata[ENTRATE_LEN];
    struct entrata *entrataMensile  = NULL;

    set_binding_param(&param[0], MYSQL_TYPE_SHORT, &annoMese->anno, sizeof(annoMese->anno));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &annoMese->mese, sizeof(annoMese->mese));
    set_binding_param(&param[2], MYSQL_TYPE_DECIMAL, entrata, strlen(entrata));

    if (mysql_stmt_bind_param(visualizza_entrata_mensile, param)) {
        print_stmt_error(visualizza_entrata_mensile, "Impossibile effettuare il binding dei parametri per do_visualizza_entrata_mensile");
        goto out;
    }

    if (mysql_stmt_execute(visualizza_entrata_mensile) != 0) {
        print_stmt_error(visualizza_entrata_mensile, "Impossibile eseguire la procedura 'visualizza_entrata_mensile'");
        goto out;
    }

    entrataMensile = malloc(sizeof *entrataMensile);
    if(entrataMensile == NULL)
        goto out;
    memset(entrataMensile, 0, sizeof(*entrataMensile));

    //output
    set_binding_param(&param[0], MYSQL_TYPE_DECIMAL, entrata, ENTRATE_LEN);

    if(mysql_stmt_bind_result(visualizza_entrata_mensile, param)) {
        print_stmt_error(visualizza_entrata_mensile, "Impossibile recuperare i parametri di output");
        free(entrataMensile);
        entrataMensile = NULL;
        goto out;
    }

    if(mysql_stmt_fetch(visualizza_entrata_mensile)) {
        print_stmt_error(visualizza_entrata_mensile, "Impossibile bufferizzare l'output");
        goto out;
    }
    strcpy(entrataMensile->tot, entrata);

    out:
    mysql_stmt_free_result(visualizza_entrata_mensile);
    while(mysql_stmt_next_result(visualizza_entrata_mensile) != -1) {}
    mysql_stmt_reset(visualizza_entrata_mensile);
    return entrataMensile;
}

void do_inserisci_tavolo(struct nuovo_tavolo *nuovoTavolo)
{
    MYSQL_BIND param[2];

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &nuovoTavolo->numeroTavolo, sizeof(nuovoTavolo->numeroTavolo));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &nuovoTavolo->numeroPosti, sizeof (nuovoTavolo->numeroPosti));

    if(mysql_stmt_bind_param(inserisci_tavolo, param) != 0) {
        print_stmt_error(inserisci_tavolo, "Impossibile effettuare il binding dei parametri per do_inserisci_tavolo");
        return;
    }

    //esecuzione procedura
    if(mysql_stmt_execute(inserisci_tavolo) != 0) {
        print_stmt_error(inserisci_tavolo, "Impossibile eseguire la procedura 'inserisci_tavolo'");
        return;
    }
    printf("\nIl tavolo %u e' stato inserito correttamente nel sistema\n", nuovoTavolo->numeroTavolo);

    mysql_stmt_free_result(inserisci_tavolo);
    mysql_stmt_reset(inserisci_tavolo);
}

void do_inserisci_cameriere(struct nuovo_cameriere *nuovoCameriere)
{
    MYSQL_BIND param[2];

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, nuovoCameriere->nome, strlen(nuovoCameriere->nome));
    set_binding_param(&param[1], MYSQL_TYPE_VAR_STRING, nuovoCameriere->cognome, strlen(nuovoCameriere->cognome));

    if(mysql_stmt_bind_param(inserisci_cameriere, param) != 0) {
        print_stmt_error(inserisci_cameriere, "Impossibile effettuare il binding dei parametri per do_inserisci_cameriere");
        return;
    }

    //esecuzione procedura
    if(mysql_stmt_execute(inserisci_cameriere) != 0) {
        print_stmt_error(inserisci_cameriere, "Impossibile eseguire la procedura 'inserisci_cameriere'");
        return;
    }
    printf("\nIl cameriere %s %s e' stato inserito correttamente nel sistema\n", nuovoCameriere->nome, nuovoCameriere->cognome);

    mysql_stmt_free_result(inserisci_cameriere);
    mysql_stmt_reset(inserisci_cameriere);
}

void do_cancella_turno_cameriere(struct turno_cameriere *turnoCameriere)
{
    MYSQL_BIND param[4];
    MYSQL_TIME data;

    date_to_mysql_time(turnoCameriere->data, &data);

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, turnoCameriere->nomeC, strlen(turnoCameriere->nomeC));
    set_binding_param(&param[1], MYSQL_TYPE_VAR_STRING, turnoCameriere->cognomeC, strlen(turnoCameriere->cognomeC));
    set_binding_param(&param[2], MYSQL_TYPE_VAR_STRING, turnoCameriere->turno, strlen(turnoCameriere->turno));
    set_binding_param(&param[3], MYSQL_TYPE_DATE, &data, sizeof(data));

    if(mysql_stmt_bind_param(cancella_turno_cameriere, param) != 0) {
        print_stmt_error(cancella_turno_cameriere, "Impossibile effettuare il binding dei parametri per do_cancella_turno_cameriere");
        return;
    }

    //esecuzione procedura
    if(mysql_stmt_execute(cancella_turno_cameriere) != 0) {
        print_stmt_error(cancella_turno_cameriere, "Impossibile eseguire la procedura 'cancella_turno_cameriere'");
        return;
    }
    puts("\nModifica eseguita correttamente");

    mysql_stmt_free_result(cancella_turno_cameriere);
    mysql_stmt_reset(cancella_turno_cameriere);
}

//-------------------  CAMERIERE  -------------------

struct lista_tavoli *do_visualizza_tavoli_occupati(char *username)
{
    int status;
    size_t row = 0;
    MYSQL_BIND param[1];
    unsigned int tavolo;
    struct lista_tavoli *tavoliOccupati = NULL;

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, username, strlen(username));

    if (mysql_stmt_bind_param(visualizza_tavoli_occupati, param)) {
        print_stmt_error(visualizza_tavoli_occupati, "Impossibile effettuare il binding dei parametri per do_visualizza_tavoli_occupati");
        goto out;
    }

    if (mysql_stmt_execute(visualizza_tavoli_occupati) != 0) {
        print_stmt_error(visualizza_tavoli_occupati, "Impossibile eseguire la procedura 'visualizza_tavoli_occupati'");
        goto out;
    }

    mysql_stmt_store_result(visualizza_tavoli_occupati);

    tavoliOccupati = malloc(sizeof (*tavoliOccupati) + sizeof(struct tavolo) * mysql_stmt_num_rows(visualizza_tavoli_occupati));
    if(tavoliOccupati == NULL)
        goto out;
    memset(tavoliOccupati, 0, sizeof(*tavoliOccupati) + sizeof(struct tavolo) * mysql_stmt_num_rows(visualizza_tavoli_occupati));
    tavoliOccupati->num_entries = mysql_stmt_num_rows(visualizza_tavoli_occupati);


    set_binding_param(&param[0], MYSQL_TYPE_LONG, &tavolo, sizeof(tavolo));

    if(mysql_stmt_bind_result(visualizza_tavoli_occupati, param)) {
        print_stmt_error(visualizza_tavoli_occupati, "Impossibile effettuare il bind dei parametri per visualizzare i tavoli occupati\n");
        free(tavoliOccupati);
        tavoliOccupati = NULL;
        goto out;
    }

    while (true) {
        status = mysql_stmt_fetch(visualizza_tavoli_occupati);

        if (status == 1 || status == MYSQL_NO_DATA)
            break;

        tavoliOccupati->tavolo[row].numeroTavolo = tavolo;

        row++;
    }
    out:
    mysql_stmt_free_result(visualizza_tavoli_occupati);
    while(mysql_stmt_next_result(visualizza_tavoli_occupati) != -1) {}
    mysql_stmt_reset(visualizza_tavoli_occupati);
    return tavoliOccupati;
}

struct lista_tavoli *do_visualizza_tavoli_comande_servite(char *username)
{
    int status;
    size_t row = 0;
    MYSQL_BIND param[1];
    unsigned int tavolo;
    unsigned int num_tavoli;
    struct lista_tavoli *tavoliComandeServite = NULL;

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, username, strlen(username));

    if (mysql_stmt_bind_param(visualizza_tavoli_comande_servite, param)) {
        print_stmt_error(visualizza_tavoli_comande_servite, "Impossibile effettuare il binding dei parametri per do_visualizza_tavoli_comande_servite");
        goto out;
    }

    if (mysql_stmt_execute(visualizza_tavoli_comande_servite) != 0) {
        print_stmt_error(visualizza_tavoli_comande_servite, "Impossibile eseguire la procedura 'visualizza_tavoli_comande_servite'");
        goto out;
    }

    mysql_stmt_store_result(visualizza_tavoli_comande_servite);
    num_tavoli = mysql_stmt_num_rows(visualizza_tavoli_comande_servite);

    tavoliComandeServite = malloc(sizeof (*tavoliComandeServite) + sizeof(struct tavolo) * num_tavoli);
    if(tavoliComandeServite == NULL)
        goto out;
    memset(tavoliComandeServite, 0, sizeof(*tavoliComandeServite) + sizeof(struct tavolo) * num_tavoli);
    tavoliComandeServite->num_entries = num_tavoli;

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &tavolo, sizeof(tavolo));

    if(mysql_stmt_bind_result(visualizza_tavoli_comande_servite, param)) {
        print_stmt_error(visualizza_tavoli_comande_servite, "Impossibile effettuare il bind dei parametri per visualizzare i tavoli in cui le comande sono state completamente servite\n");
        free(tavoliComandeServite);
        tavoliComandeServite = NULL;
        goto out;
    }

    while (true) {
        status = mysql_stmt_fetch(visualizza_tavoli_comande_servite);

        if (status == 1 || status == MYSQL_NO_DATA)
            break;

        tavoliComandeServite->tavolo[row].numeroTavolo = tavolo;

        row++;
    }
    out:
    mysql_stmt_free_result(visualizza_tavoli_comande_servite);
    while(mysql_stmt_next_result(visualizza_tavoli_comande_servite) != -1) {}
    mysql_stmt_reset(visualizza_tavoli_comande_servite);
    return tavoliComandeServite;
}


static struct da_servire *extract_comande_da_servire_info(void)
{
    struct da_servire *daServire = NULL;
    int stato;
    size_t row = 0;
    MYSQL_BIND param[2];
    unsigned int comanda;
    unsigned int tavolo;
    unsigned int num_comande;

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &comanda, sizeof(comanda));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &tavolo, sizeof(tavolo));

    if(mysql_stmt_bind_result(visualizza_cosa_e_dove_servire, param)) {
        print_stmt_error(visualizza_cosa_e_dove_servire, "Impossibile effettuare il bind dei parametri\n");
        free(daServire);
        daServire = NULL;
        goto out;
    }

    if (mysql_stmt_store_result(visualizza_cosa_e_dove_servire)) {
        print_stmt_error(visualizza_cosa_e_dove_servire, "Impossibile bufferizzare l'intero result set");
        goto out;
    }
    num_comande = mysql_stmt_num_rows(visualizza_cosa_e_dove_servire);

    daServire = malloc(sizeof(*daServire) + sizeof(struct comande_da_servire) * num_comande);
    if(daServire == NULL)
        goto out;

    memset(daServire, 0, sizeof(*daServire) + sizeof(struct comande_da_servire) * num_comande);

    daServire->num_comande = num_comande;

    while (true) {
        stato = mysql_stmt_fetch(visualizza_cosa_e_dove_servire);

        if (stato == 1 || stato == MYSQL_NO_DATA) {
            break;
        }

        daServire->comandeDaServire[row].comanda = comanda;
        daServire->comandeDaServire[row].tavolo = tavolo;

        row++;
    }
    out:
    return daServire;
}

static void *extract_prodotti_da_servire_info(struct da_servire *daServire, size_t i)
{
    int stato;
    size_t row = 0;
    MYSQL_BIND param[2];
    unsigned int id;
    char nome[NOME_PRODOTTO_LEN];
    unsigned int num_prodotti;

    assert(i < daServire->num_comande);

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &id, sizeof(id));
    set_binding_param(&param[1], MYSQL_TYPE_VAR_STRING, nome, NOME_PRODOTTO_LEN);

    if(mysql_stmt_bind_result(visualizza_cosa_e_dove_servire, param)) {
        finish_with_stmt_error(conn, visualizza_cosa_e_dove_servire, "[FATAL] Impossibile bufferizzare i parametri\n", false);
    }

    mysql_stmt_store_result(visualizza_cosa_e_dove_servire);
    num_prodotti = mysql_stmt_num_rows(visualizza_cosa_e_dove_servire);

    daServire->comandeDaServire[i].prodottiDaServire = malloc(sizeof(*daServire->comandeDaServire[i].prodottiDaServire) * num_prodotti);
    daServire->comandeDaServire[i].num_prodotti = num_prodotti;

    while (true) {
        stato = mysql_stmt_fetch(visualizza_cosa_e_dove_servire);

        if (stato == 1 || stato == MYSQL_NO_DATA) {
            break;
        }

        daServire->comandeDaServire[i].prodottiDaServire[row].id = id;
        strcpy(daServire->comandeDaServire[i].prodottiDaServire[row].nome, nome);

        row++;
    }
}

struct da_servire *do_visualizza_cosa_e_dove_servire(char *username)
{
    int stato;
    unsigned incr = 0;
    MYSQL_BIND param[1];
    struct da_servire *daServire = NULL;

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, username, strlen(username));

    if(mysql_stmt_bind_param(visualizza_cosa_e_dove_servire, param) != 0) {
        finish_with_stmt_error(conn, visualizza_cosa_e_dove_servire, "[FATAL] Impossibile bufferizzare i parametri\n", false);
        goto out;
    }

    if(mysql_stmt_execute(visualizza_cosa_e_dove_servire) != 0) {
        print_stmt_error(visualizza_cosa_e_dove_servire, "Impossibile eseguire la procedura per ottenere le cose da servire\n");
        goto out;
    }

    do {
        // vedo se la procedura contiene dei valori out o inout tramite il bit SERVER_PS_OUT_PARAMS,
        // in caso li abbia il result set che precede il valore dello stato finale (questo lo trovo facendo conn->server_status)
        //conterra' il valore dei parametri di output

        if (conn->server_status & SERVER_PS_OUT_PARAMS) {
            goto next;
        }
        if (incr == 0) {
            daServire = extract_comande_da_servire_info();
            if (daServire == NULL) {
                goto out;
            }
        } else if (incr - 1 < daServire->num_comande)
            extract_prodotti_da_servire_info(daServire, incr - 1);

        next:
        mysql_stmt_free_result(visualizza_cosa_e_dove_servire);
        stato = mysql_stmt_next_result(visualizza_cosa_e_dove_servire);
        if (stato > 0)
            finish_with_stmt_error(conn, visualizza_cosa_e_dove_servire, "Condizione inaspettata", false);
        incr++;
    } while (stato == 0);

    out:
    mysql_stmt_free_result(visualizza_cosa_e_dove_servire);
    mysql_stmt_reset(visualizza_cosa_e_dove_servire);
    return daServire;
}

void free_da_servire(struct da_servire *daServire)
{
    for (size_t i = 0; i < daServire->num_comande; i++) {
        free(daServire->comandeDaServire[i].prodottiDaServire);
    }
    free(daServire);
}


int do_registra_comanda(struct tavolo *tavolo, char *username)
{
    MYSQL_BIND param[3];
    int numeroComanda;

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &tavolo->numeroTavolo, sizeof(tavolo->numeroTavolo));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &numeroComanda, sizeof(numeroComanda));
    set_binding_param(&param[2], MYSQL_TYPE_VAR_STRING, username, strlen(username));

    if (mysql_stmt_bind_param(registra_comanda, param)) {
        print_stmt_error(registra_comanda, "Impossibile effettuare il binding dei parametri per do_registra_comanda");
        numeroComanda = -1;
        goto out;
    }

    if (mysql_stmt_execute(registra_comanda) != 0) {
        print_stmt_error(registra_comanda, "Impossibile eseguire la procedura 'registra_comanda'");
        numeroComanda = -1;
        goto out;
    }

    //output
    set_binding_param(&param[0], MYSQL_TYPE_LONG, &numeroComanda, sizeof(numeroComanda));

    if(mysql_stmt_bind_result(registra_comanda, param)) {
        print_stmt_error(registra_comanda, "Impossibile recuperare i parametri di output");
        numeroComanda = -1;
        goto out;
    }

    if(mysql_stmt_fetch(registra_comanda)) {
        print_stmt_error(registra_comanda, "Impossibile bufferizzare l'output");
        numeroComanda = -1;
        goto out;
    }

    out:
    mysql_stmt_free_result(registra_comanda);
    while(mysql_stmt_next_result(registra_comanda) != -1) {}
    mysql_stmt_reset(registra_comanda);
    return numeroComanda;
}


bool do_ordina_bevanda(struct bevanda_effettiva *bevandaEffettiva, char *username)
{
    MYSQL_BIND param[3];

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, bevandaEffettiva->nomeBevanda, strlen(bevandaEffettiva->nomeBevanda));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &bevandaEffettiva->comanda, sizeof(bevandaEffettiva->comanda));
    set_binding_param(&param[2], MYSQL_TYPE_VAR_STRING, username, strlen(username));

    if(mysql_stmt_bind_param(ordina_bevanda, param) != 0) {
        print_stmt_error(ordina_bevanda, "Impossibile effettuare il binding dei parametri per do_ordina_bevanda");
        return false;
    }

    if (mysql_stmt_execute(ordina_bevanda) != 0) {
        print_stmt_error(ordina_bevanda, "Impossibile eseguire la procedura 'ordina_bevanda'");
        return false;
    }
    printf("\nOrdinazione della bevanda '%s' effettuata correttamente\n", bevandaEffettiva->nomeBevanda);


    mysql_stmt_free_result(ordina_bevanda);
    mysql_stmt_reset(ordina_bevanda);
    return true;
}

bool do_segna_bevanda_servita(struct bevanda_stato *bevandaServita, char *username)
{
    MYSQL_BIND param[3];

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &bevandaServita->idBevanda, sizeof(bevandaServita->idBevanda));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &bevandaServita->comanda, sizeof(bevandaServita->comanda));
    set_binding_param(&param[2], MYSQL_TYPE_VAR_STRING, username, strlen(username));

    if(mysql_stmt_bind_param(segna_bevanda_servita, param) != 0) {
        print_stmt_error(segna_bevanda_servita, "Impossibile effettuare il binding dei parametri per do_segna_bevanda_servita");
        return false;
    }

    if (mysql_stmt_execute(segna_bevanda_servita) != 0) {
        print_stmt_error(segna_bevanda_servita, "Impossibile eseguire la procedura 'segna_bevanda_servita'");
        return false;
    }
    puts("\nAggiornamento dello stato della bevanda andato a buon fine");


    mysql_stmt_free_result(segna_bevanda_servita);
    mysql_stmt_reset(segna_bevanda_servita);
    return true;
}

int do_ordina_pizza(struct pizza_effettiva *pizzaEffettiva, char *username)
{
    MYSQL_BIND param[4];
    int idPizza;

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, pizzaEffettiva->nomePizza, strlen(pizzaEffettiva->nomePizza));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &pizzaEffettiva->comanda, sizeof(pizzaEffettiva->comanda));
    set_binding_param(&param[2], MYSQL_TYPE_VAR_STRING, username, strlen(username));
    set_binding_param(&param[3], MYSQL_TYPE_LONG, &idPizza, sizeof(idPizza));

    if (mysql_stmt_bind_param(ordina_pizza, param)) {
        print_stmt_error(ordina_pizza, "Impossibile effettuare il binding dei parametri per do_ordina_pizza");
        idPizza = -1;
        goto out;
    }

    if (mysql_stmt_execute(ordina_pizza) != 0) {
        print_stmt_error(ordina_pizza, "Impossibile eseguire la procedura 'ordina_pizza'");
        idPizza = -1;
        goto out;
    }

    //output
    set_binding_param(&param[0], MYSQL_TYPE_LONG, &idPizza, sizeof(idPizza));

    if(mysql_stmt_bind_result(ordina_pizza, param)) {
        print_stmt_error(ordina_pizza, "Impossibile recuperare i parametri di output");
        idPizza = -1;
        goto out;
    }

    if(mysql_stmt_fetch(ordina_pizza)) {
        print_stmt_error(ordina_pizza, "Impossibile bufferizzare l'output");
        idPizza = -1;
        goto out;
    }

    out:
    mysql_stmt_free_result(ordina_pizza);
    while(mysql_stmt_next_result(ordina_pizza) != -1) {}
    mysql_stmt_reset(ordina_pizza);
    return idPizza;
}

void do_inserisci_aggiunta_pizza(struct aggiunta_pizza *aggiunta)
{
    MYSQL_BIND param[3];

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &aggiunta->idPizza, sizeof(aggiunta->idPizza));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &aggiunta->comanda, sizeof(aggiunta->comanda));
    set_binding_param(&param[2], MYSQL_TYPE_VAR_STRING, aggiunta->ingrediente, strlen(aggiunta->ingrediente));

    if(mysql_stmt_bind_param(inserisci_aggiunta_pizza, param) != 0) {
        print_stmt_error(inserisci_aggiunta_pizza, "Impossibile effettuare il binding dei parametri per do_inserisci_aggiunta_pizza");
        return;
    }

    if (mysql_stmt_execute(inserisci_aggiunta_pizza) != 0) {
        print_stmt_error(inserisci_aggiunta_pizza, "Impossibile eseguire la procedura 'inserisci_aggiunta_pizza'");
        return;
    }
    printf("\nL'ingrediente '%s' e' stato aggiunto alla pizza %u\n", aggiunta->ingrediente, aggiunta->idPizza);

    mysql_stmt_free_result(inserisci_aggiunta_pizza);
    mysql_stmt_reset(inserisci_aggiunta_pizza);
}

void do_segna_pizza_ordinata(struct pizza_stato *pizzaOrdinata)
{
    MYSQL_BIND param[2];

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &pizzaOrdinata->idPizza, sizeof(pizzaOrdinata->idPizza));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &pizzaOrdinata->comanda, sizeof(pizzaOrdinata->comanda));

    if(mysql_stmt_bind_param(segna_pizza_ordinata, param) != 0) {
        print_stmt_error(segna_pizza_ordinata, "Impossibile effettuare il binding dei parametri per do_segna_pizza_ordinata");
        return;
    }

    if (mysql_stmt_execute(segna_pizza_ordinata) != 0) {
        print_stmt_error(segna_pizza_ordinata, "Impossibile eseguire la procedura 'segna_pizza_ordinata'");
        return;
    }
    printf("\nL'ordinazione della pizza %u e' andata a buon fine\n", pizzaOrdinata->idPizza);

    mysql_stmt_free_result(segna_pizza_ordinata);
    mysql_stmt_reset(segna_pizza_ordinata);
}

bool do_segna_pizza_servita(struct pizza_stato *pizzaServita, char *username)
{
    MYSQL_BIND param[3];

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &pizzaServita->idPizza, sizeof(pizzaServita->idPizza));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &pizzaServita->comanda, sizeof(pizzaServita->comanda));
    set_binding_param(&param[2], MYSQL_TYPE_VAR_STRING, username, strlen(username));

    if(mysql_stmt_bind_param(segna_pizza_servita, param) != 0) {
        print_stmt_error(segna_pizza_servita, "Impossibile effettuare il binding dei parametri per do_segna_pizza_servita");
        return false;
    }

    if (mysql_stmt_execute(segna_pizza_servita) != 0) {
        print_stmt_error(segna_pizza_servita, "Impossibile eseguire la procedura 'segna_pizza_servita'");
        return false;
    }
    puts("\nAggiornamneto dello stato della pizza andato a buon fine");


    mysql_stmt_free_result(segna_pizza_servita);
    mysql_stmt_reset(segna_pizza_servita);
    return true;
}



//---------------PIZZAIOLO----------------------------------

static struct pizze_da_preparare *extract_pizze_da_preparare_info(void)
{
    struct pizze_da_preparare *pizzeDaPreparare = NULL;
    int stato;
    size_t row = 0;
    MYSQL_BIND param[3];
    unsigned int comanda;
    unsigned int idPizza;
    char nomePizza[NOME_PRODOTTO_LEN];
    unsigned int num_pizze;

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &comanda, sizeof(comanda));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &idPizza, sizeof(idPizza));
    set_binding_param(&param[2], MYSQL_TYPE_VAR_STRING, nomePizza, NOME_PRODOTTO_LEN);

    if(mysql_stmt_bind_result(visualizza_pizze_da_preparare, param)) {
        print_stmt_error(visualizza_pizze_da_preparare, "Impossibile effettuare il bind dei parametri\n");
        free(pizzeDaPreparare);
        pizzeDaPreparare = NULL;
        goto out;
    }

    if (mysql_stmt_store_result(visualizza_pizze_da_preparare)) {
        print_stmt_error(visualizza_pizze_da_preparare, "Impossibile bufferizzare l'intero result set");
        goto out;
    }
    num_pizze = mysql_stmt_num_rows(visualizza_pizze_da_preparare);

    pizzeDaPreparare = malloc(sizeof(*pizzeDaPreparare) + sizeof(struct pizza_info)  * num_pizze);
    if(pizzeDaPreparare == NULL)
        goto out;

    memset(pizzeDaPreparare, 0, sizeof(*pizzeDaPreparare) + sizeof(struct pizza_info) * num_pizze);

    pizzeDaPreparare->num_pizze = num_pizze;

    while (true) {
        stato = mysql_stmt_fetch(visualizza_pizze_da_preparare);

        if (stato == 1 || stato == MYSQL_NO_DATA) {
            break;
        }

        pizzeDaPreparare->pizzaInfo[row].comanda = comanda;
        pizzeDaPreparare->pizzaInfo[row].idPizza = idPizza;
        strcpy(pizzeDaPreparare->pizzaInfo[row].nomePizza, nomePizza);

        row++;
    }
    out:
    return pizzeDaPreparare;
}

static void extract_aggiunte_info(struct pizze_da_preparare *pizzeDaPreparare, size_t i)
{
    MYSQL_BIND param[3];
    size_t row = 0;
    int stato;
    char ingrediente[NOME_PRODOTTO_LEN];

    assert(i < pizzeDaPreparare->num_pizze);

    set_binding_param(&param[0], MYSQL_TYPE_VAR_STRING, ingrediente, NOME_PRODOTTO_LEN);

    if(mysql_stmt_bind_result(visualizza_pizze_da_preparare, param)) {
        finish_with_stmt_error(conn, visualizza_pizze_da_preparare, "[FATAL] Impossibile bufferizzare i parametri\n", false);
    }
    mysql_stmt_store_result(visualizza_pizze_da_preparare);

    pizzeDaPreparare->pizzaInfo[i].aggiunte = malloc(sizeof(*pizzeDaPreparare->pizzaInfo[i].aggiunte) *
                                                     mysql_stmt_num_rows(visualizza_pizze_da_preparare));
    pizzeDaPreparare->pizzaInfo[i].num_aggiunte = mysql_stmt_num_rows(visualizza_pizze_da_preparare);

    while (true) {
        stato = mysql_stmt_fetch(visualizza_pizze_da_preparare);

        if (stato == 1 || stato == MYSQL_NO_DATA)
            break;

        strcpy(pizzeDaPreparare->pizzaInfo[i].aggiunte[row].ingrediente, ingrediente);

        row++;
    }
}

struct pizze_da_preparare *do_visualizza_pizze_da_preparare(void)
{
    int stato;
    unsigned incr = 0;
    struct pizze_da_preparare *pizzeDaPreparare = NULL;

    if(mysql_stmt_execute(visualizza_pizze_da_preparare) != 0) {
        print_stmt_error(visualizza_pizze_da_preparare, "Impossibile eseguire la procedura per ottenere le pizze da preparare\n");
        goto out;
    }
    do {
        if (conn->server_status & SERVER_PS_OUT_PARAMS) {
            goto next;
        }
        if (incr == 0) {
            pizzeDaPreparare = extract_pizze_da_preparare_info();
            if (pizzeDaPreparare == NULL) {
                goto out;
            }
        } else if (incr - 1 < pizzeDaPreparare->num_pizze) {
            extract_aggiunte_info(pizzeDaPreparare, incr - 1);
        }
        next:
        mysql_stmt_free_result(visualizza_pizze_da_preparare);
        stato = mysql_stmt_next_result(visualizza_pizze_da_preparare);
        if (stato > 0)
            finish_with_stmt_error(conn, visualizza_pizze_da_preparare, "Condizione inaspettata", false);
        incr++;
    } while (stato == 0);

    out:
    mysql_stmt_free_result(visualizza_pizze_da_preparare);
    mysql_stmt_reset(visualizza_pizze_da_preparare);
    return pizzeDaPreparare;
}

void free_pizze_da_preparare(struct pizze_da_preparare *pizzeDaPreparare)
{
    for (size_t i = 0; i < pizzeDaPreparare->num_pizze; i++) {
        free(pizzeDaPreparare->pizzaInfo[i].aggiunte);
    }
    free(pizzeDaPreparare);
}



bool do_segna_pizza_pronta(struct pizza_stato *pizzaPronta)
{
    MYSQL_BIND param[2];

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &pizzaPronta->idPizza, sizeof(pizzaPronta->idPizza));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &pizzaPronta->comanda, sizeof(pizzaPronta->comanda));

    if(mysql_stmt_bind_param(segna_pizza_pronta, param) != 0) {
        print_stmt_error(segna_pizza_pronta, "Impossibile effettuare il binding dei parametri per do_segna_pizza_pronta");
        return false;
    }

    if (mysql_stmt_execute(segna_pizza_pronta) != 0) {
        print_stmt_error(segna_pizza_pronta, "Impossibile eseguire la procedura 'segna_pizza_pronta'");
        return false;
    }
    puts("\nAggiornamento dello stato della pizza andato a buon fine");


    mysql_stmt_free_result(segna_pizza_pronta);
    mysql_stmt_reset(segna_pizza_pronta);
    return true;
}



//-----------------BARISTA---------------------------------

struct lista_bevande_da_preparare *do_visualizza_bevande_da_preparare(void)
{
    int status;
    size_t row = 0;
    MYSQL_BIND param[3];
    unsigned int comanda;
    unsigned int idBevanda;
    char nomeBevanda[NOME_PRODOTTO_LEN];
    struct lista_bevande_da_preparare *listaBevandeDaPreparare = NULL;

    if (mysql_stmt_execute(visualizza_bevande_da_preparare) != 0) {
        finish_with_stmt_error(conn, visualizza_bevande_da_preparare, "Impossibile eseguire la procedura 'visualizza_bevande_da_preparare'", false);
        goto out;
    }

    if(mysql_stmt_store_result(visualizza_bevande_da_preparare)) {
        print_stmt_error(visualizza_bevande_da_preparare, "Impossibile memorizzare la lista di bevande");
        goto out;
    }

    listaBevandeDaPreparare = malloc(sizeof (*listaBevandeDaPreparare) + sizeof(struct bevanda_da_preparare) * mysql_stmt_num_rows(visualizza_bevande_da_preparare));
    if(listaBevandeDaPreparare == NULL)
        goto out;
    memset(listaBevandeDaPreparare, 0, sizeof(*listaBevandeDaPreparare) + sizeof(struct bevanda_da_preparare) * mysql_stmt_num_rows(visualizza_bevande_da_preparare));
    listaBevandeDaPreparare->num_entries = mysql_stmt_num_rows(visualizza_bevande_da_preparare);


    set_binding_param(&param[0], MYSQL_TYPE_LONG, &comanda, sizeof(comanda));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &idBevanda, sizeof(idBevanda));
    set_binding_param(&param[2], MYSQL_TYPE_VAR_STRING, nomeBevanda, NOME_PRODOTTO_LEN);

    if(mysql_stmt_bind_result(visualizza_bevande_da_preparare, param)) {
        print_stmt_error(visualizza_bevande_da_preparare, "Impossibile effettuare il bind dei parametri per visualizzare le bevande da preparare\n");
        free(listaBevandeDaPreparare);
        listaBevandeDaPreparare = NULL;
        goto out;
    }

    while (true) {
        status = mysql_stmt_fetch(visualizza_bevande_da_preparare);

        if (status == 1 || status == MYSQL_NO_DATA)
            break;

        listaBevandeDaPreparare->bevandaDaPreparare[row].comanda = comanda;
        listaBevandeDaPreparare->bevandaDaPreparare[row].idBevanda = idBevanda;
        strcpy(listaBevandeDaPreparare->bevandaDaPreparare[row].nomeBevanda, nomeBevanda);

        row++;
    }
    out:
    mysql_stmt_free_result(visualizza_bevande_da_preparare);
    while(mysql_stmt_next_result(visualizza_bevande_da_preparare) != -1) {}
    mysql_stmt_reset(visualizza_bevande_da_preparare);
    return listaBevandeDaPreparare;
}

bool do_segna_bevanda_pronta(struct bevanda_stato *bevandaPronta)
{
    MYSQL_BIND param[2];

    set_binding_param(&param[0], MYSQL_TYPE_LONG, &bevandaPronta->idBevanda, sizeof(bevandaPronta->idBevanda));
    set_binding_param(&param[1], MYSQL_TYPE_LONG, &bevandaPronta->comanda, sizeof(bevandaPronta->comanda));

    if(mysql_stmt_bind_param(segna_bevanda_pronta, param) != 0) {
        print_stmt_error(segna_bevanda_pronta, "Impossibile effettuare il binding dei parametri per do_segna_bevanda_pronta");
        return false;
    }

    if (mysql_stmt_execute(segna_bevanda_pronta) != 0) {
        print_stmt_error(segna_bevanda_pronta, "Impossibile eseguire la procedura 'segna_bevanda_pronta'");
        return false;
    }
    puts("\nAggiornamento dello stato della bevanda andato a buon fine");


    mysql_stmt_free_result(segna_bevanda_pronta);
    mysql_stmt_reset(segna_bevanda_pronta);
    return true;
}
